import os
from dotenv import load_dotenv

load_dotenv()

TELEGRAM_BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "")
LINODE_API_TOKEN = os.getenv("LINODE_API_TOKEN", "")

DEFAULT_RDP_USER = os.getenv("DEFAULT_RDP_USER", "Administrator")
DEFAULT_RDP_PASS = os.getenv("DEFAULT_RDP_PASS", "Teddysun.com")
DEFAULT_RDP_PORT = int(os.getenv("DEFAULT_RDP_PORT", "3389"))

ADMIN_TELEGRAM_ID = int(os.getenv("ADMIN_TELEGRAM_ID", "7118252117"))

allowed_users_raw = os.getenv("ALLOWED_TELEGRAM_USERS", "")
ALLOWED_TELEGRAM_USERS = (
    [int(u.strip()) for u in allowed_users_raw.split(",") if u.strip().isdigit()]
    if allowed_users_raw
    else []
)

# Katalog Image Windows (100% English Edition / en-us) dari https://dl.lamp.sh/vhd/
# VHD/RAW images terkompresi .xz dengan VirtIO driver bawaan
WINDOWS_IMAGES = {
    "win2012": {
        "name": "Windows Server 2012 R2 (EN)",
        "url": "https://dl.lamp.sh/vhd/en_win2012r2.xz",
        "desc": "Windows Server 2012 R2 64-bit English (Ringan & Cepat)",
    },
    "win2016": {
        "name": "Windows Server 2016 (EN)",
        "url": "https://dl.lamp.sh/vhd/en_win2016.xz",
        "desc": "Windows Server 2016 Datacenter 64-bit English",
    },
    "win2019": {
        "name": "Windows Server 2019 (EN)",
        "url": "https://dl.lamp.sh/vhd/en_win2019.xz",
        "desc": "Windows Server 2019 Datacenter 64-bit English",
    },
    "win2022": {
        "name": "Windows Server 2022 (EN-US)",
        "url": "https://dl.lamp.sh/vhd/en-us_win2022.xz",
        "desc": "Windows Server 2022 Datacenter 64-bit English",
    },
    "win2025": {
        "name": "Windows Server 2025 (EN-US)",
        "url": "https://dl.lamp.sh/vhd/en-us_win2025.xz",
        "desc": "Windows Server 2025 Datacenter 64-bit English",
    },
    "win10": {
        "name": "Windows 10 Enterprise LTSC (EN-US)",
        "url": "https://dl.lamp.sh/vhd/en-us_windows10_ltsc.xz",
        "desc": "Windows 10 Enterprise LTSC 64-bit English",
    },
    "win11": {
        "name": "Windows 11 Enterprise (EN-US)",
        "url": "https://dl.lamp.sh/vhd/en-us_windows11.xz",
        "desc": "Windows 11 Enterprise 64-bit English",
    },
    "tiny10": {
        "name": "Tiny 10 23H2 (EN-US Super Ringan)",
        "url": "https://dl.lamp.sh/vhd/tiny10_23h2.xz",
        "desc": "Tiny 10 23H2 64-bit English (Debloated & Super Ringan)",
    },
    "tiny11": {
        "name": "Tiny 11 23H2 (EN-US Super Ringan)",
        "url": "https://dl.lamp.sh/vhd/tiny11_23h2.xz",
        "desc": "Tiny 11 23H2 64-bit English (Debloated & Modern)",
    },
}

# Tipe / Plan Linode (Khusus Shared CPU - Max 16GB 6-Core)
LINODE_TYPES = {
    "g6-nanode-1": "Nanode 1GB (1 vCPU, 1GB RAM, 25GB Storage)",
    "g6-standard-1": "Standard 2GB (1 vCPU, 2GB RAM, 50GB Storage)",
    "g6-standard-2": "Standard 4GB (2 vCPU, 4GB RAM, 80GB Storage) ⭐ Rekomendasi",
    "g6-standard-4": "Standard 8GB (4 vCPU, 8GB RAM, 160GB Storage)",
    "g6-standard-6": "Standard 16GB (6 vCPU, 16GB RAM, 320GB Storage) 🔥 Max",
}

# Region Linode Populer
LINODE_REGIONS = {
    "ap-south": "Singapore (SG)",
    "jp-osa": "Osaka, Japan (JP)",
    "ap-northeast": "Tokyo, Japan (JP)",
    "us-east": "Newark, NJ, USA",
    "us-west": "Fremont, CA, USA",
    "eu-west": "London, UK",
    "eu-central": "Frankfurt, Germany",
    "id-cgk": "Jakarta, Indonesia (ID)",
}

# Base OS Ubuntu 22.04 LTS Linode Image
LINODE_UBUNTU_IMAGE = "linode/ubuntu22.04"
