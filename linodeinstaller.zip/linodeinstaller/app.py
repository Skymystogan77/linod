from flask import Flask, request, jsonify, render_template_string
import google.genai as genai
from PIL import Image
import io
import json
import os
import re

app = Flask(__name__)

# CONFIGURATION
API_KEY = os.getenv("GEMINI_API_KEY", "AQ.Ab8RN6LCP11EXUSjuSCEEf9bPs4E8RBdtFVwX4Z1SsZl3lwieQ")

# Menggunakan SDK Resmi Baru (google-genai)
client = genai.Client(api_key=API_KEY)

HTML_TEMPLATE = """
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>XAUUSD AI PRO - Live Engine</title>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
  <script src="https://unpkg.com/lucide@latest"></script>
  <style>
    :root {
      --bg-main: #0B0E14; --bg-card: #151921; --bg-accent: #1E232F; --border: #2A303C;
      --accent-blue: #2563EB; --accent-green: #10B981; --accent-red: #EF4444; --accent-amber: #F59E0B;
      --text-primary: #F3F4F6; --text-secondary: #9CA3AF;
    }
    * { box-sizing: border-box; margin: 0; padding: 0; font-family: 'Inter', sans-serif; }
    body { background-color: var(--bg-main); color: var(--text-primary); min-height: 100vh; display: flex; flex-direction: column; }
    header { background-color: var(--bg-card); border-bottom: 1px solid var(--border); padding: 1rem 1.5rem; display: flex; justify-content: space-between; align-items: center; }
    .brand { display: flex; align-items: center; gap: 0.75rem; font-weight: 700; font-size: 1.25rem; }
    .brand i { color: var(--accent-blue); }
    .dashboard { display: grid; grid-template-columns: 320px 1fr 340px; gap: 1rem; padding: 1rem; flex: 1; }
    @media (max-width: 1024px) { .dashboard { grid-template-columns: 1fr; } }
    .panel { background-color: var(--bg-card); border: 1px solid var(--border); border-radius: 12px; padding: 1.25rem; display: flex; flex-direction: column; gap: 1.25rem; }
    .panel-title { font-size: 1rem; font-weight: 600; color: var(--text-secondary); display: flex; align-items: center; gap: 0.5rem; }
    .upload-box { border: 2px dashed var(--border); border-radius: 10px; padding: 2rem 1rem; text-align: center; cursor: pointer; background-color: rgba(255, 255, 255, 0.01); }
    .upload-box:hover { border-color: var(--accent-blue); }
    .btn-primary { background-color: var(--accent-blue); color: #fff; border: none; padding: 0.85rem; border-radius: 8px; font-size: 1rem; font-weight: 600; cursor: pointer; display: flex; align-items: center; justify-content: center; gap: 0.5rem; }
    .chart-box { width: 100%; height: 450px; background-color: #0B0E14; border-radius: 8px; border: 1px solid var(--border); position: relative; overflow: hidden; display: flex; align-items: center; justify-content: center; }
    .preview-img { max-width: 100%; max-height: 100%; object-fit: contain; }
    .signal-card { background-color: var(--bg-accent); border-radius: 10px; padding: 1.25rem; display: flex; justify-content: space-between; align-items: center; border-left: 5px solid var(--accent-green); }
    .signal-card.sell { border-left-color: var(--accent-red); }
    .signal-type { font-size: 1.5rem; font-weight: 700; color: var(--accent-green); display: flex; align-items: center; gap: 0.5rem; }
    .signal-type.sell { color: var(--accent-red); }
    .metrics-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 0.75rem; }
    .metric-box { background-color: var(--bg-accent); padding: 0.85rem; border-radius: 8px; border: 1px solid var(--border); }
    .metric-label { font-size: 0.75rem; color: var(--text-secondary); margin-bottom: 0.25rem; }
    .metric-value { font-size: 1.15rem; font-weight: 700; }
    .val-entry { color: #3B82F6; } .val-sl { color: var(--accent-red); } .val-tp { color: var(--accent-green); } .val-lot { color: #A855F7; }
    .analysis-list { display: flex; flex-direction: column; gap: 0.75rem; font-size: 0.85rem; color: var(--text-secondary); max-height: 220px; overflow-y: auto; }
    .analysis-item { background-color: var(--bg-accent); padding: 0.75rem; border-radius: 8px; line-height: 1.4; }
    .analysis-item strong { color: var(--text-primary); }
    .overlay { position: absolute; top: 0; left: 0; right: 0; bottom: 0; background: rgba(11, 14, 20, 0.9); display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 1rem; border-radius: 12px; opacity: 0; pointer-events: none; transition: opacity 0.3s; z-index: 10; }
    .overlay.active { opacity: 1; pointer-events: all; }
    .spinner { width: 40px; height: 40px; border: 4px solid var(--border); border-top: 4px solid var(--accent-blue); border-radius: 50%; animation: spin 1s linear infinite; }
    @keyframes spin { 100% { transform: rotate(360deg); } }
  </style>
</head>
<body>
  <header>
    <div class="brand"><i data-lucide="cpu"></i><span>XAUUSD AI PRO (Gemini Vision Backend)</span></div>
  </header>
  <div class="dashboard">
    <div class="panel">
      <div class="panel-title"><i data-lucide="upload-cloud"></i> Input Chart</div>
      <div class="upload-box" onclick="document.getElementById('file-input').click()">
        <p id="upload-text">Upload Screenshot Chart XAUUSD</p>
        <input type="file" id="file-input" style="display:none" accept="image/*" onchange="previewImage(event)">
      </div>
      <button class="btn-primary" onclick="analyzeChart()"><i data-lucide="zap"></i> ANALISIS DENGAN GEMINI FLASH</button>
    </div>

    <div class="panel" style="position:relative;">
      <div class="panel-title"><i data-lucide="image"></i> Screenshot Preview</div>
      <div class="chart-box">
        <img id="img-preview" class="preview-img" style="display:none;">
        <span id="placeholder-text" style="color:var(--text-secondary)">Belum ada gambar di-upload</span>
      </div>
      <div class="overlay" id="loading-overlay">
        <div class="spinner"></div>
        <p>GEMINI VISION SEDANG MEMBACA CHART...</p>
      </div>
    </div>

    <div class="panel">
      <div class="panel-title"><i data-lucide="activity"></i> Hasil Analisis Real Gemini</div>
      <div class="signal-card" id="signal-card">
        <div>
          <div style="font-size:0.75rem; color:var(--text-secondary)">SIGNAL</div>
          <div class="signal-type" id="signal-text">READY</div>
        </div>
        <div style="text-align:right">
          <div style="font-size:0.75rem; color:var(--text-secondary)">WIN RATE</div>
          <div style="font-size:1.25rem; font-weight:700; color:var(--accent-green)" id="val-acc">-</div>
        </div>
      </div>
      <div class="metrics-grid">
        <div class="metric-box"><div class="metric-label">LOT</div><div class="metric-value val-lot">0.01</div></div>
        <div class="metric-box"><div class="metric-label">ENTRY</div><div class="metric-value val-entry" id="val-entry">-</div></div>
        <div class="metric-box"><div class="metric-label">STOP LOSS</div><div class="metric-value val-sl" id="val-sl">-</div></div>
        <div class="metric-box"><div class="metric-label">TAKE PROFIT (1:2)</div><div class="metric-value val-tp" id="val-tp">-</div></div>
      </div>
      <div class="analysis-list">
        <div class="analysis-item" id="reason-smc"><strong>SMC & Price Action:</strong> Tunggu upload...</div>
        <div class="analysis-item" id="reason-fibo"><strong>Fibonacci & Trend:</strong> Tunggu upload...</div>
      </div>
    </div>
  </div>

  <script>
    lucide.createIcons();
    let selectedFile = null;

    function previewImage(event) {
      selectedFile = event.target.files[0];
      if (selectedFile) {
        document.getElementById('upload-text').innerText = selectedFile.name;
        const reader = new FileReader();
        reader.onload = function(e) {
          const img = document.getElementById('img-preview');
          img.src = e.target.result;
          img.style.display = 'block';
          document.getElementById('placeholder-text').style.display = 'none';
        }
        reader.readAsDataURL(selectedFile);
      }
    }

    async function analyzeChart() {
      if (!selectedFile) {
        alert("Upload gambar chart terlebih dahulu!");
        return;
      }

      const overlay = document.getElementById('loading-overlay');
      overlay.classList.add('active');

      const formData = new FormData();
      formData.append('file', selectedFile);

      try {
        const res = await fetch('/analyze', { method: 'POST', body: formData });
        const data = await res.json();

        if (data.error) {
          alert("Gagal: " + data.error);
        } else {
          document.getElementById('signal-text').innerText = data.signal;
          document.getElementById('val-acc').innerText = data.win_rate + '%';
          document.getElementById('val-entry').innerText = data.entry;
          document.getElementById('val-sl').innerText = data.sl;
          document.getElementById('val-tp').innerText = data.tp;
          document.getElementById('reason-smc').innerHTML = "<strong>SMC & Price Action:</strong> " + data.smc_analysis;
          document.getElementById('reason-fibo').innerHTML = "<strong>Fibonacci & Trend:</strong> " + data.fibo_analysis;

          const card = document.getElementById('signal-card');
          const text = document.getElementById('signal-text');
          if (data.signal === 'BUY') {
            card.classList.remove('sell');
            text.classList.remove('sell');
          } else {
            card.classList.add('sell');
            text.classList.add('sell');
          }
        }
      } catch (err) {
        alert("Terjadi kesalahan sistem server.");
      } finally {
        overlay.classList.remove('active');
      }
    }
  </script>
</body>
</html>
"""

@app.route('/')
def home():
    return render_template_string(HTML_TEMPLATE)

@app.route('/analyze', methods=['POST'])
def analyze():
    if 'file' not in request.files:
        return jsonify({'error': 'File tidak ditemukan'}), 400
    
    file = request.files['file']
    if file.filename == '':
        return jsonify({'error': 'Tidak ada file terpilih'}), 400

    try:
        image_bytes = file.read()
        image = Image.open(io.BytesIO(image_bytes))

        prompt = """
        Anda adalah Analis Trading Forex Professional spesialis XAUUSD.
        Analisis gambar chart XAUUSD yang diberikan secara objektif menggunakan teknik SMC (Smart Money Concepts), Order Block, Price Action, dan Fibonacci Retracement.
        Tentukan Stop Loss (SL) dan Take Profit (TP) dengan rasio Risk to Reward persis 1:2.

        Keluarkan hasil analisis HANYA dalam format JSON berikut tanpa markdown atau teks tambahan:
        {
          "signal": "BUY" atau "SELL",
          "win_rate": 85-95,
          "entry": "angka_entry",
          "sl": "angka_sl",
          "tp": "angka_tp",
          "smc_analysis": "Penjelasan singkat area Order Block / Liquidity",
          "fibo_analysis": "Penjelasan level Retracement / Trend"
        }
        """

        # Menggunakan model terbaru gemini-3.6-flash sesuai pesan error Google
        response = client.models.generate_content(
            model='gemini-3.6-flash',
            contents=[prompt, image]
        )

        clean_json = re.sub(r'```json\s*|\s*```', '', response.text).strip()
        data = json.loads(clean_json)

        return jsonify(data)

    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=False)
