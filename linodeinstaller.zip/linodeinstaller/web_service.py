import json
import logging
import asyncio
from datetime import datetime
from typing import Dict, Any
from aiohttp import web

logger = logging.getLogger(__name__)

# In-memory storage untuk seluruh tugas deployment
DEPLOYMENT_TASKS: Dict[str, Dict[str, Any]] = {}


def register_task(task_id: str, label: str, ip: str, os_name: str, region: str) -> Dict[str, Any]:
    """Mendaftarkan tugas deploy baru ke Web Dashboard."""
    task_data = {
        "id": task_id,
        "label": label,
        "ip": ip or "Menunggu Alokasi...",
        "os": os_name or "Windows",
        "region": region or "N/A",
        "status": "Running",
        "step": "[1/5] Memulai Proses",
        "detail": "Mengirim permintaan pembuatan instance ke Linode API...",
        "progress_pct": 10,
        "user": "",
        "password": "",
        "port": 3389,
        "logs": [],
        "start_time": datetime.now().strftime("%H:%M:%S"),
        "updated_at": datetime.now().strftime("%H:%M:%S"),
    }
    DEPLOYMENT_TASKS[task_id] = task_data
    return task_data


def update_task(task_id: str, **kwargs):
    """Mengupdate status tugas deploy secara real-time."""
    if task_id in DEPLOYMENT_TASKS:
        task = DEPLOYMENT_TASKS[task_id]
        for key, val in kwargs.items():
            if val is not None:
                task[key] = val
        task["updated_at"] = datetime.now().strftime("%H:%M:%S")


def add_task_log(task_id: str, log_line: str):
    """Menambahkan catatan log ke task tertentu."""
    if task_id in DEPLOYMENT_TASKS:
        logs = DEPLOYMENT_TASKS[task_id]["logs"]
        timestamp = datetime.now().strftime("%H:%M:%S")
        logs.append(f"[{timestamp}] {log_line}")
        if len(logs) > 60:
            logs.pop(0)


async def handle_index(request: web.Request) -> web.Response:
    """Mengembalikan halaman HTML Web Dashboard (Dark Theme)."""
    html_content = """<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Linode Windows Auto-Deploy Dashboard</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            background-color: #0b0e14;
            color: #e2e8f0;
            font-family: system-ui, -apple-system, sans-serif;
            padding-bottom: 40px;
        }
        .navbar {
            background: #111827;
            border-bottom: 1px solid #1f2937;
        }
        .card-custom {
            background: #111827;
            border: 1px solid #1f2937;
            border-radius: 12px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.5);
            margin-bottom: 20px;
        }
        .badge-running {
            background-color: #0284c7;
            color: #fff;
            padding: 6px 14px;
            border-radius: 20px;
            font-size: 0.85rem;
            animation: pulse 2s infinite;
        }
        .badge-success {
            background-color: #16a34a;
            color: #fff;
            padding: 6px 14px;
            border-radius: 20px;
            font-size: 0.85rem;
        }
        .badge-failed {
            background-color: #dc2626;
            color: #fff;
            padding: 6px 14px;
            border-radius: 20px;
            font-size: 0.85rem;
        }
        @keyframes pulse {
            0% { opacity: 1; }
            50% { opacity: 0.6; }
            100% { opacity: 1; }
        }
        .progress-bar-custom {
            background: linear-gradient(90deg, #38bdf8 0%, #6366f1 100%);
            border-radius: 6px;
        }
        .log-box {
            background-color: #030712;
            border: 1px solid #1f2937;
            border-radius: 8px;
            color: #38bdf8;
            font-family: 'Courier New', Courier, monospace;
            font-size: 0.85rem;
            height: 160px;
            overflow-y: auto;
            padding: 12px;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark mb-4 py-3">
        <div class="container">
            <a class="navbar-brand d-flex align-items-center gap-2 fw-bold" href="#">
                <i class="fa-brands fa-windows text-info fs-3"></i>
                <span>Linode Windows Installer Dashboard</span>
            </a>
            <div class="d-flex align-items-center gap-3">
                <span class="badge bg-secondary" id="activeCount">0 Proses Aktif</span>
                <span class="text-muted small" id="liveClock">00:00:00</span>
            </div>
        </div>
    </nav>

    <div class="container">
        <div id="noTaskAlert" class="alert alert-dark text-center border-secondary py-5">
            <i class="fa-solid fa-server fs-1 text-muted mb-3 d-block"></i>
            <h5>Belum ada proses instalasi yang sedang berjalan.</h5>
            <p class="text-muted mb-0">Mulai instalasi dari Telegram Bot dengan perintah <code>/deploy</code>.</p>
        </div>

        <div id="taskList"></div>
    </div>

    <script>
        function updateClock() {
            const now = new Date();
            document.getElementById('liveClock').innerText = now.toLocaleTimeString('id-ID');
        }
        setInterval(updateClock, 1000);
        updateClock();

        async function fetchTasks() {
            try {
                const res = await fetch('/api/tasks');
                const tasks = await res.json();
                renderTasks(tasks);
            } catch (err) {
                console.error('Error fetching tasks:', err);
            }
        }

        function renderTasks(tasks) {
            const container = document.getElementById('taskList');
            const noAlert = document.getElementById('noTaskAlert');
            const keys = Object.keys(tasks);
            
            document.getElementById('activeCount').innerText = `${keys.length} Proses Aktif`;

            if (keys.length === 0) {
                noAlert.classList.remove('d-none');
                container.innerHTML = '';
                return;
            } else {
                noAlert.classList.add('d-none');
            }

            let html = '';
            keys.reverse().forEach(id => {
                const task = tasks[id];
                let badgeClass = 'badge-running';
                if (task.status === 'Success') badgeClass = 'badge-success';
                if (task.status === 'Failed') badgeClass = 'badge-failed';

                const logsText = (task.logs || []).join('\\n');

                let credsHtml = '';
                if (task.status === 'Success' && task.user) {
                    credsHtml = `
                    <div class="alert alert-success p-3 mb-3">
                        <div class="fw-bold mb-1"><i class="fa-solid fa-key me-1"></i> Kredensial Login Windows RDP:</div>
                        <div>🌐 <strong>IP:</strong> <code>${task.ip}:${task.port}</code></div>
                        <div>👤 <strong>Username:</strong> <code>${task.user}</code></div>
                        <div>🔑 <strong>Password:</strong> <code>${task.password}</code></div>
                    </div>
                    `;
                }

                html += `
                <div class="card-custom p-4">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <div>
                            <h5 class="fw-bold text-white mb-1"><i class="fa-brands fa-windows text-info me-2"></i> ${task.label || task.id}</h5>
                            <span class="text-muted small">Target IP: <strong class="text-warning">${task.ip}</strong> | OS: <strong>${task.os}</strong> | Region: <strong>${task.region}</strong></span>
                        </div>
                        <div>
                            <span class="${badgeClass}">${task.status}</span>
                        </div>
                    </div>

                    ${credsHtml}

                    <div class="mb-3">
                        <div class="d-flex justify-content-between mb-1">
                            <span class="small fw-semibold text-info"><i class="fa-solid fa-spinner fa-spin me-1"></i> ${task.step}</span>
                            <span class="small fw-bold text-white">${task.progress_pct}%</span>
                        </div>
                        <div class="progress" style="height: 10px; background-color: #030712;">
                            <div class="progress-bar progress-bar-custom" role="progressbar" style="width: ${task.progress_pct}%;"></div>
                        </div>
                    </div>

                    <div class="row g-2 mb-3 text-center">
                        <div class="col-6 col-md-3">
                            <div class="p-2 rounded bg-dark border border-secondary">
                                <div class="text-muted small">Status</div>
                                <div class="fw-bold text-info">${task.status}</div>
                            </div>
                        </div>
                        <div class="col-6 col-md-3">
                            <div class="p-2 rounded bg-dark border border-secondary">
                                <div class="text-muted small">Mulai</div>
                                <div class="fw-bold text-white">${task.start_time}</div>
                            </div>
                        </div>
                        <div class="col-6 col-md-3">
                            <div class="p-2 rounded bg-dark border border-secondary">
                                <div class="text-muted small">Update Terakhir</div>
                                <div class="fw-bold text-white">${task.updated_at}</div>
                            </div>
                        </div>
                        <div class="col-6 col-md-3">
                            <div class="p-2 rounded bg-dark border border-secondary">
                                <div class="text-muted small">Port RDP</div>
                                <div class="fw-bold text-success">${task.port}</div>
                            </div>
                        </div>
                    </div>

                    <div>
                        <div class="small text-muted mb-1"><i class="fa-solid fa-terminal me-1"></i> Log Instalasi Terkini:</div>
                        <div class="log-box" id="log-${task.id}">${logsText || 'Menunggu output...'}</div>
                    </div>
                </div>
                `;
            });

            container.innerHTML = html;

            keys.forEach(id => {
                const el = document.getElementById(`log-${id}`);
                if (el) el.scrollTop = el.scrollHeight;
            });
        }

        setInterval(fetchTasks, 2000);
        fetchTasks();
    </script>
</body>
</html>
"""
    return web.Response(text=html_content, content_type="text/html")


async def handle_api_tasks(request: web.Request) -> web.Response:
    """API JSON mengembalikan daftar seluruh tugas deploy aktif."""
    return web.json_response(DEPLOYMENT_TASKS)


async def start_web_dashboard(host: str = "0.0.0.0", port: int = 3000):
    """Menjalankan Web Server Dashboard aiohttp di port 3000."""
    try:
        app = web.Application()
        app.router.add_get("/", handle_index)
        app.router.add_get("/api/tasks", handle_api_tasks)

        runner = web.AppRunner(app)
        await runner.setup()
        site = web.TCPSite(runner, host, port)
        await site.start()
        logger.info(f"Web Dashboard aktif di http://{host}:{port}")
        print(f"[DASHBOARD] Web Dashboard aktif di http://localhost:{port}")
    except Exception as e:
        logger.warning(f"Gagal menjalankan Web Dashboard pada port {port}: {e}")
