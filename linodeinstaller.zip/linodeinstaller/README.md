# 🤖 Bot Telegram: Auto-Deploy Linode & Reinstall Windows RDP (English Edition)

Bot Telegram cerdas untuk mengotomatiskan seluruh alur pembuatan VPS di Linode dengan base **Ubuntu 22.04 LTS**, injeksi script install Windows otomatis 1-klik (menggunakan template image VHD English dari `https://dl.lamp.sh/vhd/` serta script `InstallNET.sh` / `reinstall.sh`), konfigurasi kredensial Administrator (`Buyerute123#`), dan pengujian port RDP secara real-time sampai aktif.

---

## 🌟 Fitur Utama

1. **Alur Linode Otomatis**:
   - Pembuatan instance Linode berbasis Ubuntu 22.04 LTS secara instan via Linode API v4.
   - Deteksi IP Public dan status `running`.
2. **Injeksi Script Windows 1-Klik (English Edition)**:
   - Terkoneksi via SSH otomatis ke server Ubuntu baru.
   - Menjalankan script reinstaller Windows (kompatibel dengan `InstallNET.sh` dan `reinstall.sh` bin456789).
   - Menggunakan image VHD resmi **English (EN-US 64-bit)** dari repository `https://dl.lamp.sh/vhd/` yang sudah dilengkapi driver VirtIO storage & network.
   - Mengatur password default: `Buyerute123#` untuk user `Administrator`.
3. **Realtime RDP & TCP Port Tester**:
   - Polling socket berkala (setiap 15 detik) untuk mendeteksi kapan Windows selesai booting dan port RDP (3389 / port pilihan) siap menerima koneksi.
   - Handshake packet X.224 / T.125 untuk memvalidasi respons service RDP.
   - Command `/testrdp <ip> [port]` untuk cek status port VPS kapan pun.
4. **Manajemen Instance**:
   - `/instances`: Melihat daftar VPS yang sedang aktif beserta tombol cek RDP dan tombol hapus instance.

---

## 📋 Katalog Image Windows English (`dl.lamp.sh/vhd/`)

| Sistem Operasi | Bahasa | Link Image VHD |
|---|---|---|
| Windows Server 2012 R2 | English (EN-US 64-bit) | `https://dl.lamp.sh/vhd/en-us_windows_server_2012_r2.vhd.gz` |
| Windows Server 2016 Datacenter | English (EN-US 64-bit) | `https://dl.lamp.sh/vhd/en-us_windows_server_2016_datacenter.vhd.gz` |
| Windows Server 2019 Datacenter | English (EN-US 64-bit) | `https://dl.lamp.sh/vhd/en-us_windows_server_2019_datacenter.vhd.gz` |
| Windows Server 2022 Datacenter | English (EN-US 64-bit) | `https://dl.lamp.sh/vhd/en-us_windows_server_2022_datacenter.vhd.gz` |
| Windows 10 Enterprise LTSC | English (EN-US 64-bit) | `https://dl.lamp.sh/vhd/en-us_windows_10_enterprise_ltsc_2021.vhd.gz` |
| Windows 11 Enterprise | English (EN-US 64-bit) | `https://dl.lamp.sh/vhd/en-us_windows_11_enterprise.vhd.gz` |

---

## 🚀 Panduan Instalasi & Menjalankan Bot

### 1. Prasyarat
- Python 3.9+ terinstal di sistem Anda.
- Akun Telegram (untuk membuat bot via [@BotFather](https://t.me/BotFather)).
- Akun Linode & Personal Access Token (dengan permission `Linodes: Read/Write`).

### 2. Install Dependensi
Buka terminal di folder project ini dan jalankan:
```bash
py -m pip install -r requirements.txt
```

### 3. Konfigurasi `.env`
Salin file `.env.example` menjadi `.env`:
```powershell
Copy-Item .env.example .env
```
Lalu edit file `.env`:
```env
TELEGRAM_BOT_TOKEN=123456789:ABCdefGhIJKlmNoPQRsTUVwxyZ
LINODE_API_TOKEN=your_linode_personal_access_token_here

DEFAULT_RDP_USER=Administrator
DEFAULT_RDP_PASS=Buyerute123#
DEFAULT_RDP_PORT=3389

# Opsional: Batasi hanya ID Telegram Anda yang bisa akses bot (kosongkan jika publik)
ALLOWED_TELEGRAM_USERS=
```

### 4. Menjalankan Bot
```bash
py bot.py
```

---

## 📱 Cara Menggunakan Bot di Telegram

1. Buka bot Anda di Telegram dan ketik `/start`.
2. Klik tombol **🚀 Deploy Windows RDP** (atau ketik `/deploy`).
3. Pilih **Region** (misal: Singapore, Tokyo, Jakarta, USA, Frankfurt, dll).
4. Pilih **Tipe Linode** (Disarankan minimal **Standard 4GB** untuk performa Windows yang lancar).
5. Pilih **Versi Windows English** yang diinginkan (Server 2012, 2016, 2019, 2022, Win 10, atau Win 11).
6. Tekan **🚀 Eksekusi Deploy Sekarang!**.
7. Bot akan memproses langkah demi langkah secara otomatis hingga Windows RDP online!
