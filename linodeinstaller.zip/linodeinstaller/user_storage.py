import json
import os
import logging
from typing import Optional, Dict, Any

logger = logging.getLogger(__name__)

DATA_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
STORAGE_FILE = os.path.join(DATA_DIR, "user_api_keys.json")


def _ensure_storage_exists():
    """Memastikan direktori data dan file storage JSON ada."""
    if not os.path.exists(DATA_DIR):
        os.makedirs(DATA_DIR, exist_ok=True)
    if not os.path.exists(STORAGE_FILE):
        with open(STORAGE_FILE, "w", encoding="utf-8") as f:
            json.dump({}, f, indent=2)


def load_all_users() -> Dict[str, Dict[str, Any]]:
    """Memuat semua data pengguna dari file JSON."""
    _ensure_storage_exists()
    try:
        with open(STORAGE_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception as e:
        logger.error(f"Gagal membaca file {STORAGE_FILE}: {e}")
        return {}


def _save_all_users(data: Dict[str, Dict[str, Any]]) -> bool:
    """Menyimpan seluruh data pengguna ke file JSON."""
    _ensure_storage_exists()
    try:
        with open(STORAGE_FILE, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
        return True
    except Exception as e:
        logger.error(f"Gagal menulis ke file {STORAGE_FILE}: {e}")
        return False


def get_user_api_token(user_id: int) -> Optional[str]:
    """Mendapatkan Linode API Token milik user tertentu."""
    users = load_all_users()
    user_data = users.get(str(user_id))
    if user_data and "api_token" in user_data:
        return user_data["api_token"].strip()
    return None


def get_user_data(user_id: int) -> Optional[Dict[str, Any]]:
    """Mendapatkan data lengkap user (token, info telegram, info linode, dll)."""
    users = load_all_users()
    return users.get(str(user_id))


def save_user_api_token(
    user_id: int,
    api_token: str,
    telegram_user: Optional[Dict[str, Any]] = None,
    linode_account_info: Optional[Dict[str, Any]] = None,
) -> bool:
    """Menyimpan atau memperbarui Linode API Token untuk user tertentu."""
    users = load_all_users()
    key = str(user_id)
    if key not in users:
        users[key] = {}

    users[key]["api_token"] = api_token.strip()
    if telegram_user:
        users[key]["telegram"] = telegram_user
    if linode_account_info:
        users[key]["linode"] = linode_account_info

    import datetime
    users[key]["updated_at"] = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    return _save_all_users(users)


def delete_user_api_token(user_id: int) -> bool:
    """Menghapus token user."""
    users = load_all_users()
    key = str(user_id)
    if key in users:
        del users[key]
        return _save_all_users(users)
    return False
