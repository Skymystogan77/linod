import aiohttp
import asyncio
import secrets
import string
import logging
from typing import Dict, Any, Optional, List

logger = logging.getLogger(__name__)

LINODE_API_BASE = "https://api.linode.com/v4"


def generate_temp_password(length: int = 20) -> str:
    """Menghasilkan password acak yang kuat dan memenuhi kriteria keamanan Linode."""
    characters = string.ascii_letters + string.digits + "!@#$%^&*"
    while True:
        password = "".join(secrets.choice(characters) for _ in range(length))
        if (
            any(c.isupper() for c in password)
            and any(c.islower() for c in password)
            and any(c.isdigit() for c in password)
            and any(c in "!@#$%^&*" for c in password)
        ):
            return password


class LinodeService:
    def __init__(self, api_token: str):
        self.api_token = api_token.strip()
        self.headers = {
            "Authorization": f"Bearer {self.api_token}",
            "Content-Type": "application/json",
        }

    async def _request(
        self, method: str, endpoint: str, json_data: Optional[Dict] = None
    ) -> Dict[str, Any]:
        url = f"{LINODE_API_BASE}/{endpoint.lstrip('/')}"
        async with aiohttp.ClientSession(headers=self.headers) as session:
            async with session.request(method, url, json=json_data) as response:
                status = response.status
                if status == 204:
                    return {"success": True}
                try:
                    res_json = await response.json()
                except Exception:
                    text = await response.text()
                    res_json = {"error": text}

                if status >= 400:
                    errors = res_json.get("errors", [])
                    error_msg = "; ".join(
                        [e.get("reason", str(e)) for e in errors]
                    ) if errors else str(res_json)
                    raise Exception(f"Linode API Error ({status}): {error_msg}")

                return res_json

    async def get_profile(self) -> Dict[str, Any]:
        """Mendapatkan profil user Linode (username, email, dll)."""
        return await self._request("GET", "/profile")

    async def get_account(self) -> Dict[str, Any]:
        """Mendapatkan info akun Linode (balance, credit, status, dll)."""
        return await self._request("GET", "/account")

    async def validate_token(self) -> Dict[str, Any]:
        """Memvalidasi apakah API token aktif dan mengembalikan data akun & profil."""
        profile = await self.get_profile()
        account = {}
        try:
            account = await self.get_account()
        except Exception:
            # Token mungkin memiliki restricted scope (tidak ada access account), tapi profil bisa dibaca
            pass
        return {"valid": True, "profile": profile, "account": account}

    async def list_instances(self) -> List[Dict[str, Any]]:
        """Mendapatkan daftar instance Linode."""
        res = await self._request("GET", "/linode/instances")
        return res.get("data", [])

    async def get_instance(self, instance_id: int) -> Dict[str, Any]:
        """Mendapatkan detail instance Linode."""
        return await self._request("GET", f"/linode/instances/{instance_id}")

    async def create_instance(
        self,
        label: str,
        region: str,
        plan_type: str,
        root_pass: Optional[str] = None,
        image: str = "linode/ubuntu22.04",
    ) -> Dict[str, Any]:
        """Membuat instance Linode baru dengan base Ubuntu 22.04 LTS."""
        if not root_pass:
            root_pass = generate_temp_password()

        payload = {
            "label": label,
            "region": region,
            "type": plan_type,
            "image": image,
            "root_pass": root_pass,
            "booted": True,
        }

        instance = await self._request("POST", "/linode/instances", json_data=payload)
        instance["temp_root_pass"] = root_pass
        return instance

    async def wait_for_running(
        self, instance_id: int, timeout_seconds: int = 300, interval: int = 6
    ) -> Dict[str, Any]:
        """Menunggu status instance menjadi 'running' dan memiliki IPv4 public."""
        elapsed = 0
        while elapsed < timeout_seconds:
            inst = await self.get_instance(instance_id)
            status = inst.get("status")
            ipv4_list = inst.get("ipv4", [])

            if status == "running" and len(ipv4_list) > 0:
                return inst

            await asyncio.sleep(interval)
            elapsed += interval

        raise TimeoutError(f"Linode {instance_id} timeout saat menunggu status 'running'.")

    async def configure_windows_profile(self, instance_id: int) -> bool:
        """
        Mengubah Linode Configuration Profile untuk booting Windows:
        - kernel: 'linode/direct-disk' (Direct Disk MBR/GPT booting)
        - virt_mode: 'fullvirt' (Full KVM Virtualization)
        - helpers: distro/network/modules_dep semuanya disabled
        - root_device: '/dev/sda'
        """
        # 1. Ambil daftar config profile
        res = await self._request("GET", f"/linode/instances/{instance_id}/configs")
        configs = res.get("data", [])
        if not configs:
            raise Exception("Tidak ada configuration profile pada Linode ini.")
        config_id = configs[0].get("id")

        # 2. Ambil disk ID utama (sda)
        res_disks = await self._request("GET", f"/linode/instances/{instance_id}/disks")
        disks = res_disks.get("data", [])
        if not disks:
            raise Exception("Tidak ada disk yang ditemukan pada Linode ini.")
        
        # Disk terbesar adalah disk utama Ubuntu/Windows
        sda_disk = sorted(disks, key=lambda d: d.get("size", 0), reverse=True)[0]
        sda_id = sda_disk.get("id")

        # 3. Update profile ke Direct Disk & FullVirt
        payload = {
            "kernel": "linode/direct-disk",
            "virt_mode": "fullvirt",
            "helpers": {
                "distro": False,
                "network": False,
                "modules_dep": False,
                "devtmpfs_automount": False,
                "updatedb_disabled": False,
            },
            "root_device": "/dev/sda",
            "devices": {
                "sda": {"disk_id": sda_id},
                "sdb": None,
            },
        }
        await self._request("PUT", f"/linode/instances/{instance_id}/configs/{config_id}", json_data=payload)
        logger.info(f"Linode {instance_id} profile {config_id} berhasil diupdate ke direct-disk & fullvirt.")
        return True

    async def reboot_instance(self, instance_id: int) -> bool:
        """Melakukan reboot instance Linode."""
        await self._request("POST", f"/linode/instances/{instance_id}/reboot")
        return True

    async def delete_instance(self, instance_id: int) -> bool:
        """Menghapus instance Linode."""
        await self._request("DELETE", f"/linode/instances/{instance_id}")
        return True
