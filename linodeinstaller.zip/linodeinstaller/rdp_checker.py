import asyncio
import socket
import time
import logging
from typing import Callable, Optional, Tuple, Any

logger = logging.getLogger(__name__)

# Standard RDP (X.224 / T.125) Connection Request PDU
RDP_HANDSHAKE_PACKET = bytes([
    0x03, 0x00, 0x00, 0x13,  # TPKT Header (length 19)
    0x0E,                    # X.224 length indicator
    0xE0,                    # CR (Connection Request) code
    0x00, 0x00,              # DST-REF
    0x00, 0x00,              # SRC-REF
    0x00,                    # Class & options
    0x01, 0x00, 0x08, 0x00,  # RDP Negotiation Request (TYPE_RDP_NEG_REQ)
    0x03, 0x00, 0x00, 0x00   # requestedProtocols: PROTOCOL_RDP | PROTOCOL_SSL | PROTOCOL_HYBRID
])


def check_tcp_port(host: str, port: int, timeout: float = 3.0) -> bool:
    """Cek sederhana apakah TCP port terbuka dan menerima koneksi."""
    try:
        with socket.create_connection((host, port), timeout=timeout):
            return True
    except (socket.timeout, socket.error, OSError):
        return False


def test_rdp_handshake(host: str, port: int = 3389, timeout: float = 4.0) -> Tuple[bool, str]:
    """
    Menguji port dan melakukan handshake RDP.
    Mengembalikan (is_ready, pesan_status).
    """
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(timeout)
        sock.connect((host, port))

        # Kirim RDP Handshake PDU
        try:
            sock.sendall(RDP_HANDSHAKE_PACKET)
            response = sock.recv(1024)
            sock.close()

            if response and len(response) >= 4 and response[0] == 0x03:
                return True, "RDP Handshake Sukses! Service RDP siap melayani koneksi."
            elif response:
                return True, f"Port {port} terbuka dan merespons data ({len(response)} bytes)."
            else:
                return True, f"Port {port} terbuka (TCP Connected)."
        except Exception:
            sock.close()
            return True, f"Port {port} terbuka."

    except socket.timeout:
        return False, f"Connection timeout ke {host}:{port}"
    except ConnectionRefusedError:
        return False, f"Connection refused pada {host}:{port} (Service belum aktif)"
    except Exception as e:
        return False, f"Error: {e}"


async def poll_rdp_until_ready(
    host: str,
    port: int = 3389,
    timeout_minutes: int = 25,
    poll_interval: int = 15,
    status_callback: Optional[Callable[[str, int], Any]] = None,
) -> bool:
    """
    Polling secara berkala hingga port RDP aktif dan merespons.
    Mengirimkan update berkala via status_callback.
    """
    start_time = time.time()
    max_seconds = timeout_minutes * 60
    last_update_minute = -1

    loop = asyncio.get_running_loop()

    while time.time() - start_time < max_seconds:
        elapsed = int(time.time() - start_time)
        elapsed_min = elapsed // 60
        elapsed_sec = elapsed % 60

        is_open = await loop.run_in_executor(None, check_tcp_port, host, port, 4.0)

        if is_open:
            ready, msg = await loop.run_in_executor(None, test_rdp_handshake, host, port, 5.0)
            if ready:
                logger.info(f"RDP {host}:{port} READY dalam {elapsed_min}m {elapsed_sec}s! ({msg})")
                return True

        if status_callback and (elapsed_min != last_update_minute or elapsed < 30):
            last_update_minute = elapsed_min
            status_text = (
                f"⏳ Sedang menginstal Windows & menunggu RDP online...\n"
                f"⏱️ Waktu berjalan: {elapsed_min}m {elapsed_sec}s (Target port: {port})"
            )
            try:
                if asyncio.iscoroutinefunction(status_callback):
                    await status_callback(status_text, elapsed)
                else:
                    res = status_callback(status_text, elapsed)
                    if asyncio.iscoroutine(res):
                        await res
            except Exception as e:
                logger.warning(f"Callback error: {e}")

        await asyncio.sleep(poll_interval)

    return False
