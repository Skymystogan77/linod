import time
import socket
import logging
import paramiko
import asyncio
import base64
from typing import Callable, Optional, Any

logger = logging.getLogger(__name__)

# Web Server script yang berjalan 100% di RAM (/dev/shm) pada VPS target Ubuntu
UBUNTU_WEB_SERVER_SCRIPT = '''import http.server
import json
import os
import re
import socketserver

PORT = 3000
LOG_FILE = "/dev/shm/progress.log"

HTML_TEMPLATE = """<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Linode Windows DD Live Monitor</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            background-color: #0d1117;
            color: #c9d1d9;
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Helvetica, Arial, sans-serif;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        .monitor-card {
            background-color: #161b22;
            border: 1px solid #30363d;
            border-radius: 16px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.8);
            width: 100%;
            max-width: 720px;
            overflow: hidden;
        }
        .card-header-custom {
            background-color: #21262d;
            border-bottom: 1px solid #30363d;
            padding: 18px 24px;
        }
        .pulse-dot {
            display: inline-block;
            width: 10px;
            height: 10px;
            border-radius: 50%;
            background-color: #2ea043;
            box-shadow: 0 0 10px #2ea043;
            animation: pulse 1.5s infinite;
        }
        @keyframes pulse {
            0% { transform: scale(0.95); opacity: 0.8; }
            50% { transform: scale(1.3); opacity: 1; }
            100% { transform: scale(0.95); opacity: 0.8; }
        }
        .progress-custom {
            background-color: #0d1117;
            border-radius: 10px;
            height: 22px;
            overflow: hidden;
            border: 1px solid #30363d;
        }
        .progress-bar-fill {
            background: linear-gradient(90deg, #1f6feb 0%, #388bfd 50%, #2ea043 100%);
            transition: width 0.5s ease;
        }
        .console-box {
            background-color: #090d13;
            border: 1px solid #30363d;
            border-radius: 10px;
            font-family: 'Consolas', 'Courier New', monospace;
            font-size: 0.82rem;
            color: #58a6ff;
            height: 180px;
            overflow-y: auto;
            padding: 12px;
            white-space: pre-wrap;
            word-break: break-all;
        }
        .stat-card {
            background-color: #21262d;
            border: 1px solid #30363d;
            border-radius: 10px;
            padding: 12px;
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="monitor-card">
        <div class="card-header-custom d-flex justify-content-between align-items-center">
            <div class="d-flex align-items-center gap-2">
                <i class="fa-brands fa-windows text-info fs-4"></i>
                <span class="fw-bold fs-5 text-white">Linode Windows DD Live Monitor</span>
            </div>
            <div class="d-flex align-items-center gap-2">
                <span class="pulse-dot"></span>
                <span class="small fw-semibold text-success" id="liveStatus">Live Streaming</span>
            </div>
        </div>
        <div class="p-4">
            <div class="mb-4">
                <div class="d-flex justify-content-between align-items-center mb-2">
                    <span class="fw-semibold text-white" id="stepName"><i class="fa-solid fa-spinner fa-spin me-2 text-info"></i>Menulis Image Windows (.xz) ke Disk (/dev/sda)...</span>
                    <span class="fw-bold text-info fs-5" id="pctText">0%</span>
                </div>
                <div class="progress progress-custom">
                    <div class="progress-bar progress-bar-fill" id="progressBar" role="progressbar" style="width: 0%"></div>
                </div>
            </div>

            <div class="row g-3 mb-4">
                <div class="col-4">
                    <div class="stat-card">
                        <div class="text-muted small mb-1"><i class="fa-solid fa-hard-drive me-1"></i> Data Ditulis</div>
                        <div class="fw-bold text-white fs-6" id="writtenText">0 MB</div>
                    </div>
                </div>
                <div class="col-4">
                    <div class="stat-card">
                        <div class="text-muted small mb-1"><i class="fa-solid fa-gauge-high me-1"></i> Kecepatan</div>
                        <div class="fw-bold text-info fs-6" id="speedText">-- MB/s</div>
                    </div>
                </div>
                <div class="col-4">
                    <div class="stat-card">
                        <div class="text-muted small mb-1"><i class="fa-solid fa-clock me-1"></i> Waktu Berjalan</div>
                        <div class="fw-bold text-warning fs-6" id="elapsedText">0s</div>
                    </div>
                </div>
            </div>

            <div>
                <div class="d-flex justify-content-between align-items-center mb-2">
                    <span class="small text-muted"><i class="fa-solid fa-terminal me-1"></i> Terminal DD Stream:</span>
                    <span class="badge bg-secondary" id="logLinesCount">Live Stream</span>
                </div>
                <div class="console-box" id="consoleBox">Menunggu stream proses penulisan disk...</div>
            </div>

            <div class="alert alert-info mt-4 mb-0 py-2 px-3 small border-0 d-flex align-items-center gap-2" style="background-color: #1f293d;">
                <i class="fa-solid fa-circle-info text-info fs-5"></i>
                <div>
                    Setelah penulisan selesai 100%, server otomatis me-reboot ke <strong>Windows RDP (Port 3389)</strong> dan halaman monitor ini akan offline.
                </div>
            </div>
        </div>
    </div>

    <script>
        let done = false;
        async function pollStatus() {
            if (done) return;
            try {
                const res = await fetch('/api/status');
                const data = await res.json();

                document.getElementById('writtenText').innerText = data.written || '0 MB';
                document.getElementById('speedText').innerText = data.speed || '-- MB/s';
                document.getElementById('elapsedText').innerText = data.elapsed || '0s';
                document.getElementById('pctText').innerText = data.pct + '%';
                document.getElementById('progressBar').style.width = data.pct + '%';
                
                if (data.status === 'Completed') {
                    done = true;
                    document.getElementById('liveStatus').innerText = 'Selesai';
                    document.getElementById('liveStatus').className = 'small fw-semibold text-warning';
                    document.getElementById('stepName').innerHTML = '<i class="fa-solid fa-check text-success me-2"></i>Penulisan Disk Selesai! Me-reboot ke Windows...';
                    document.getElementById('pctText').innerText = '100%';
                    document.getElementById('progressBar').style.width = '100%';
                }

                if (data.logs) {
                    const box = document.getElementById('consoleBox');
                    box.innerText = data.logs;
                    box.scrollTop = box.scrollHeight;
                }
            } catch(e) {
                console.log(e);
            }
        }
        setInterval(pollStatus, 1000);
        pollStatus();
    </script>
</body>
</html>
"""

class RequestHandler(http.server.BaseHTTPRequestHandler):
    def log_message(self, format, *args):
        pass

    def do_GET(self):
        if self.path == "/api/status":
            written = "0 MB"
            speed = "-- MB/s"
            elapsed = "0s"
            pct = 10
            status = "Running"
            logs = "Menunggu stream dd..."

            if os.path.exists(LOG_FILE):
                try:
                    with open(LOG_FILE, "r", encoding="utf-8", errors="ignore") as f:
                        content = f.read()
                    lines = [line.strip() for line in content.splitlines() if line.strip()]
                    if lines:
                        logs = "\\n".join(lines[-20:])
                        for line in reversed(lines):
                            if "copied" in line:
                                m_stat = re.search(r'copied,\\s*([^,]+),\\s*([^,]+)', line)
                                if m_stat:
                                    elapsed = m_stat.group(1).strip()
                                    speed = m_stat.group(2).strip()

                                m_size = re.search(r'\\(([^,]+),', line)
                                if m_size:
                                    written = m_size.group(1).strip()
                                else:
                                    written = line.split("copied")[0].strip()
                                
                                try:
                                    bytes_str = line.split()[0].strip()
                                    bytes_num = int(bytes_str)
                                    est_pct = int((bytes_num / (10 * 1024 * 1024 * 1024)) * 85) + 10
                                    pct = min(95, max(10, est_pct))
                                except Exception:
                                    pass
                                break

                        if "DD_COMPLETED_SUCCESSFULLY" in content:
                            status = "Completed"
                            pct = 100
                            written = "Selesai"
                except Exception as e:
                    logs = f"Error reading log: {e}"

            resp = json.dumps({
                "status": status,
                "pct": pct,
                "written": written,
                "speed": speed,
                "elapsed": elapsed,
                "logs": logs
            }).encode("utf-8")

            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Access-Control-Allow-Origin", "*")
            self.send_header("Content-Length", str(len(resp)))
            self.end_headers()
            self.wfile.write(resp)
        else:
            resp = HTML_TEMPLATE.encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(resp)))
            self.end_headers()
            self.wfile.write(resp)

def run():
    socketserver.TCPServer.allow_reuse_address = True
    with socketserver.TCPServer(("0.0.0.0", PORT), RequestHandler) as httpd:
        httpd.serve_forever()

if __name__ == "__main__":
    run()
'''


def wait_for_ssh(
    ip: str,
    port: int = 22,
    timeout: int = 240,
    interval: int = 4,
) -> bool:
    """Menunggu port SSH terbuka sebelum mencoba login."""
    start_time = time.time()
    while time.time() - start_time < timeout:
        try:
            with socket.create_connection((ip, port), timeout=3):
                return True
        except (socket.timeout, socket.error):
            time.sleep(interval)
    return False


class SSHInstaller:
    def __init__(self, ip: str, username: str = "root", password: str = "", port: int = 22):
        self.ip = ip
        self.username = username
        self.password = password
        self.port = port
        self.client: Optional[paramiko.SSHClient] = None

    def connect(self, retries: int = 12, retry_delay: int = 5) -> bool:
        """Melakukan koneksi SSH dengan retry."""
        self.client = paramiko.SSHClient()
        self.client.set_missing_host_key_policy(paramiko.AutoAddPolicy())

        last_err = None
        for i in range(retries):
            try:
                self.client.connect(
                    hostname=self.ip,
                    port=self.port,
                    username=self.username,
                    password=self.password,
                    timeout=15,
                    banner_timeout=30,
                    auth_timeout=30,
                )
                logger.info(f"SSH terhubung ke {self.ip}:{self.port}")
                return True
            except Exception as e:
                last_err = e
                logger.warning(f"Percobaan SSH {i+1}/{retries} gagal: {e}")
                time.sleep(retry_delay)

        raise Exception(f"Gagal melakukan koneksi SSH ke {self.ip}: {last_err}")

    def execute_windows_dd(
        self,
        image_url: str,
        progress_callback: Optional[Callable[[str], Any]] = None,
    ) -> bool:
        """
        Menulis image Windows VHD langsung ke disk fisik (/dev/sda)
        menggunakan streaming wget | xz -dc | dd of=/dev/sda dengan
        live web monitor di port 3000 berbasis RAM (/dev/shm).
        """
        if not self.client:
            raise Exception("SSH Client belum terhubung!")

        if progress_callback:
            progress_callback("Mempersiapkan tools di Ubuntu (wget, xz-utils, gzip)...")

        prep_cmd = (
            "DEBIAN_FRONTEND=noninteractive apt-get update -y && "
            "DEBIAN_FRONTEND=noninteractive apt-get install -y wget curl xz-utils gzip util-linux python3"
        )
        stdin, stdout, stderr = self.client.exec_command(prep_cmd, timeout=120)
        stdout.channel.recv_exit_status()

        # Luncurkan Web Monitor di port 3000 target VPS (berjalan 100% di RAM /dev/shm)
        try:
            web_b64 = base64.b64encode(UBUNTU_WEB_SERVER_SCRIPT.encode("utf-8")).decode("ascii")
            start_web_cmd = (
                f"echo '{web_b64}' | base64 -d > /dev/shm/web.py && "
                f"nohup python3 /dev/shm/web.py > /dev/shm/web.log 2>&1 &"
            )
            self.client.exec_command(start_web_cmd, timeout=15)
            logger.info(f"Web Monitor di VPS {self.ip}:3000 berhasil diluncurkan di RAM!")
        except Exception as e:
            logger.warning(f"Gagal meluncurkan web monitor di VPS: {e}")

        if progress_callback:
            progress_callback("Sedang mendownload & menulis image Windows (.xz) langsung ke disk...")

        if ".xz" in image_url:
            decomp = "xz -dc"
        else:
            decomp = "gzip -dc"

        dd_command = f"""
TARGET_DISK="/dev/sda"
[ ! -b "$TARGET_DISK" ] && TARGET_DISK=$(lsblk -dpno NAME | grep -E '(sda|vda)' | head -n1)
echo "Streaming image using {decomp} to $TARGET_DISK..." > /dev/shm/progress.log
(wget --no-check-certificate --tries=5 --timeout=20 -qO- "{image_url}" | {decomp} | dd of=$TARGET_DISK bs=4M status=progress conv=fdatasync) 2>&1 | tr '\\r' '\\n' | tee -a /dev/shm/progress.log
echo "DD_COMPLETED_SUCCESSFULLY" | tee -a /dev/shm/progress.log
"""
        stdin, stdout, stderr = self.client.exec_command(dd_command, timeout=1800)

        last_update_time = 0
        for line in stdout:
            clean_line = line.strip()
            if not clean_line:
                continue
            logger.info(f"DD Output: {clean_line}")
            if "DD_COMPLETED_SUCCESSFULLY" in clean_line:
                logger.info("DD Selesai! Mempersiapkan reboot...")
                break
            now = time.time()
            if "copied" in clean_line and (now - last_update_time >= 25):
                last_update_time = now
                if progress_callback:
                    progress_callback(clean_line)

        if progress_callback:
            progress_callback("Penulisan image Windows selesai! Mengonfigurasi Direct-Disk & me-reboot Linode...")

        self.close()
        return True

    def close(self):
        if self.client:
            try:
                self.client.close()
            except Exception:
                pass
            self.client = None


async def run_injection_task(
    ip: str,
    root_pass: str,
    image_url: str,
    progress_callback: Optional[Callable[[str], Any]] = None,
) -> bool:
    """Async wrapper untuk menjalankan penulisan Windows DD via SSH."""
    loop = asyncio.get_running_loop()

    def report(msg_str: str):
        if progress_callback:
            try:
                if asyncio.iscoroutinefunction(progress_callback):
                    asyncio.run_coroutine_threadsafe(progress_callback(msg_str), loop)
                else:
                    res = progress_callback(msg_str)
                    if asyncio.iscoroutine(res):
                        asyncio.run_coroutine_threadsafe(res, loop)
            except Exception as e:
                logger.warning(f"Error pada progress callback: {e}")

    def _sync_task():
        report(f"Menunggu port SSH (22) pada {ip} siap...")

        if not wait_for_ssh(ip, port=22, timeout=240):
            raise TimeoutError(f"Port SSH pada {ip} tidak merespons dalam 4 menit.")

        report(f"SSH siap! Melakukan login ke {ip}...")

        ssh = SSHInstaller(ip=ip, username="root", password=root_pass, port=22)
        ssh.connect(retries=12, retry_delay=5)
        return ssh.execute_windows_dd(
            image_url=image_url,
            progress_callback=report,
        )

    return await loop.run_in_executor(None, _sync_task)
